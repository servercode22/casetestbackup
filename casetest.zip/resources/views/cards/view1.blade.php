<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Card</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="css/card1.css">
    <link href="https://fonts.cdnfonts.com/css/lorem-ipsum" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>

    <input type="hidden" name="getValue" id="getValue" value="2">

    <div class="container-fluid mb-3 py-2" style="background-color: black;">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-6 text-center">
                <img src="{{asset('img/true_crime.svg')}}" alt="">
            </div>
            <div class="col-md-6 text-center">
                <img src="{{asset('img/black_hand.svg')}}" alt=""> 
            </div>
        </div>
    </div>
    


    <div class="container" id="card_main_2">
                <div class="row text-center">
                    <div class="col-md-12">
                        <p class="p_main">
                            Well done for getting this far, Inspector. Now for the last piece of the puzzle. There are two pairs
                            of evidence that, when viewed together, lin Samuel Lima to the crime.
                        </p>
                        <h4 class="h2_font_style">Can you select them both?</h4>
                    </div>
                </div>

        <div class="row">
            {{-- img no 01 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-10.png" class="firstevidence small-image small-image1 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-10.png" id="hover-image"
                        class="hover-image hover-image1 img-fluid" alt="">


                    <img src="/img/evidence/EVIDENCE FOLDER-10.png" class="lastevidence lastevidence1 img-fluid"
                        id="lastevidence" alt="">
                </div>
            </div>
            {{-- img no 02 --}}
            <!-- Add the remaining columns with adjusted column classes -->
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-11.png" class="firstevidence small-image small-image2 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-11.png" id="hover-image"
                            class="hover-image hover-image2 img-fluid" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-11.png" class="img-fluid lastevidence lastevidence2"
                            id="lastevidence" alt="">
                </div>
            </div>
            {{-- img no 03 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-4.png" class="firstevidence small-image small-image3 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-4.png" id="hover-image" class="hover-image img-fluid hover-image3"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-4.png" class="lastevidence img-fluid lastevidence3" id=""
                            alt="">
                </div>
            </div>
       
        
            {{-- img no 04 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-7.png" class="firstevidence small-image small-image4 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-7.png" id="hover-image" class="hover-image img-fluid hover-image4"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-7.png" id="lastevidence"
                            class="lastevidence img-fluid lastevidence4" alt="" data-value="4">
                </div>
            </div>

        </div>
        
        <div class="row">
            {{-- img no 05 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER.png" id="firstevidence"
                        class="firstevidence small-image small-image5 img-fluid" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER.png" id="hover-image" class="hover-image img-fluid hover-image5"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER.png" id="lastevidence"
                            class="lastevidence lastevidence5 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 06 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-2.png" class="firstevidence small-image small-image6 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-2.png" id="hover-image"
                        class="hover-image hover-image6 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-2.png" id="lastevidence"
                        class="lastevidence lastevidence6 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 07 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-5.png" class="firstevidence small-image small-image7 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-5.png" id="hover-image"
                        class="hover-image hover-image7 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-5.png" id="lastevidence lastevidence5"
                        class="lastevidence lastevidence7 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 08 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-8.png" class="firstevidence small-image small-image8 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-8.png" id="hover-image"
                        class="hover-image hover-image8 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-8.png" id="lastevidence"
                        class="lastevidence lastevidence8 img-fluid" alt="" data-value="8">
                </div>
            </div>
        </div>
        <div class="row">
            {{-- img no 09 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-1.png" class="firstevidence small-image small-image9 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-1.png" id="hover-image"
                        class="hover-image hover-image9 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-1.png" id="lastevidence"
                        class="lastevidence lastevidence9 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 10 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-3.png" class="firstevidence small-image small-image10 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-3.png" id="hover-image"
                        class="hover-image hover-image10 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-3.png" id="lastevidence"
                        class="lastevidence lastevidence10 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 11 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select">
                    <img src="/img/EVIDENCE FOLDER-6.png" class="firstevidence small-image small-image11 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-6.png" id="hover-image"
                        class="hover-image hover-image11 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-6.png" id="lastevidence"
                        class="lastevidence lastevidence11 img-fluid" alt="" data-value="11">
                </div>
            </div>
            {{-- img no 12 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container only_two_select" id="handInHandMatchBox">
                    <img src="/img/EVIDENCE FOLDER-9.png" class="firstevidence small-image small-image12 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-9.png" id="hover-image"
                        class="hover-image hover-image12 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-9.png" id="lastevidence"
                        class="lastevidence lastevidence12 img-fluid" alt="" data-value="12">
                </div>
            </div>
        </div>

        <div class="col-md-12 text-center mt-5" id="hideShowImage">
            <button class="btn" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                
                <img src="{{asset('img/buttons/D_submite_white.png')}}" class="img-fluid  btn1 text-center"
                    alt="" id="D_submite_white">

                <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center" id="buttons_countine"
                    alt="">
            </button>
        </div>





    

        {{-- exampleModalCente statr --}}

        <div class="modal fade" id="exampleModalCente" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
            data-keyboard="false">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body mt-4">
                        <div class="p-5 mt-5 mb-5">
                        <h2 class="contact-img-header text-center mb-5 mt-5">Hmm...</h2>

                        <p class="contact-img-style text-center mb-5">
                            Sorry inspector, that doesn’t look quite right.
                        </p>


                        <h4 class="contact-img-style text-center"></h4>
                        <button class="btn mt-5 mb-5" id="TryAgainModalButtons">
                            <img src="{{asset('img/buttons/d_try_again_white.png')}}" id="buttons_image_try_again_white" alt="">

                            <img src="/img/buttons/AUTO BUTTON-1.png" class="img-fluid  btn2 zoom" id="buttons_image_try_again" alt="">
                        </button>
                    </div>
                </div>
                    <style>


                        .modal-content {
                        background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                        background-repeat: no-repeat;
                        background-size: cover;
                        /*  background-position: center;
                       background-size: auto;
                        height: 100%; */
                        }


                        .modal-body {
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: center;
                            text-align: center;
                            height: 100%;
                            color: white
                        }
                    </style>
                </div>
            </div>
        </div>
        {{--exampleModalCente End --}}


                {{-- almostCorrect statr --}}

                <div class="modal fade" id="almostCorrect" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                data-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-body mb-4">
                            <div class="p-5 mt-5 mb-5">
                            <h2 class="contact-img-header text-center mb-5 mt-5">Almost....</h2>
    
                            <p class="contact-img-style text-center mb-5">
                                One of the pieces was correct...but the other wasn’t
                            </p>
    
    
                            <h4 class="contact-img-style text-center"></h4>
                            <button class="btn mt-5 mb-5" id="AlmostImage">
                                <img src="{{asset('img/buttons/D_continue.png')}}" class="img-fluid  btn2 zoom" id="buttons_image_almost_white" alt="">
                                <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom" id="buttons_image_almost" alt="">
                            </button>
                        </div>
                    </div>
                        <style>
    
    
                            .modal-content {
                            background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                            background-repeat: no-repeat;
                            background-size: cover;
                            /*  background-position: center;
                           background-size: auto;
                            height: 100%; */
                            }
    
    
                            .modal-body {
                                display: flex;
                                flex-direction: column;
                                align-items: center;
                                justify-content: center;
                                text-align: center;
                                height: 100%;
                                color: white
                            }
                        </style>
                    </div>
                </div>
            </div>
            {{--almostCorrect End --}}
             
        {{-- Strat Match box 2 --}}
        <div class="modal fade" id="matchbox2" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
        data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="p-5 mt-3">
                    <h2 class="contact-img-header text-center mb-5 mt-5">Excellent Work, Inspector.</h2>

                    <p class="contact-img-style text-center">
                      We Know from the Columbus Dispatch that Battaglia and Ventola were both suspected hitmen for the Black Hand mafia. The threatening letter gives John Amicon until the end of May to comply. Once that deadline passed, sam lima chose to 
                    contact both hitmen. Coincidence? Not Likely
                    </p>


                    <p class="contact-img-style text-center mb-3">You're doing great so far - but we still need more evidence. Can any remaining pieces of evidence be linked together to prove Sam Lima's guilty?</p>
                    <button class="btn mb-5"  id="matchboxtwoSelect">
                        <img src="{{asset('img/buttons/D_continue.png')}}" id="D_continue"
                        alt="">
                      <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom" id="buttons_image"
                            alt="">
                    </button>
                </div>
            </div>
                <style>


                    .modal-content {
                    background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                    background-repeat: no-repeat;
                    background-size: cover;
                    /*  background-position: center;
                   background-size: auto;
                    height: 100%; */
                    }


                    .modal-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        height: 100%;
                        color: white
                    }
                </style>
            </div>
        </div>
    </div>


        {{-- End Match box 2 --}}
        
        {{-- End newspaper 1 container_mian_2--}}

        <div class="modal fade" id="newspaper1" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
        data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="p-5 mt-5">
                    <h2 class="contact-img-header text-center mb-5 mt-5">Excellent Work, Inspector.</h2>

                    <p class="contact-img-style text-center">
                        The message on the matchbox proves that Sam Lima was the one minding the store when the delivery arrived. That puts him at the Hand-in-Hand Saloon On April 23rd - the day Bonito Gaito heard someone threatening John Amicon. 
                    </p>


                    <p class="contact-img-style text-center mb-2">You're doing great so far - but we still need more evidence. Can any remaining pieces of evidence be linked together to prove Sam Lima's guilty?</p>
                    <button class="btn mb-3" id="NewspaperWhite">
                        <img src="{{asset('img/buttons/D_continue.png')}}" class="img-fluid  btn2 zoom" id="buttons_image_newsspaper_1_white"
                            alt="">
                        <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom" id="buttons_image_newsspaper_1"
                            alt="">
                            
                    </button>
                </div>
            </div>
                <style>


                    .modal-content {
                    background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                    background-repeat: no-repeat;
                    background-size: cover;
                    /*  background-position: center;
                   background-size: auto;
                    height: 100%; */
                    }


                    .modal-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        height: 100%;
                        color: white
                    }
                </style>
            </div>
        </div>
    </div>

        {{-- News paper 1 end Modal container_mian_2--}}
      
        
                


        {{-- 2nd Modal contaier Start--}}


        <!-- Modal -->
        <div class="modal fade" id="matchbox1" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
            data-keyboard="false">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <img src="{{asset('img/matchbox1.jpeg')}}" class="img-fluid  btn1 text-center"alt="">
             
        </div>
    </div>

        {{-- 2nd Modal conatiner end  --}}

      

    </div>
{{-- matchboxtwoSelect Start --}}

</div> 
{{-- End container card_main_2--}}


    



{{-- Start container card_main_3--}}
    <div class="container d-none" id="card_main_3">
            <div class="row text-center">
                <div class="col-md-12">
                    <p class="p_main">
                        Well done for getting this far, Inspector. Now for the last piece of the puzzle.There are two pairs
                        of evidence that, when viewed Together, link Samuel Lima to the crime.
                    </p>
                    <h4 class="p_main">Can you select them both?</h4>
                </div>
            </div>

            <div class="row">
            {{-- img no 01 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container four_img_select">
                    <img src="/img/EVIDENCE FOLDER-10.png" class="firstevidence small-image small-image1 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-10.png" id="hover-image"
                        class="hover-image hover-image1 img-fluid" alt="">


                    <img src="/img/evidence/EVIDENCE FOLDER-10.png" class="lastevidence lastevidence1 img-fluid"
                        id="lastevidence" alt="">
                </div>
            </div>
                    {{-- img no 02 --}}
                    <!-- Add the remaining columns with adjusted column classes -->
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER-11.png" class="firstevidence small-image small-image2 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-11.png" id="hover-image"
                                    class="hover-image hover-image2 img-fluid" alt="">
                                <img src="/img/evidence/EVIDENCE FOLDER-11.png" class="img-fluid lastevidence lastevidence2"
                                    id="lastevidence" alt="">
                        </div>
                    </div>
                    {{-- img no 03 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER-4.png" class="firstevidence small-image small-image3 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-4.png" id="hover-image" class="hover-image img-fluid hover-image3"
                                    alt="">
                                <img src="/img/evidence/EVIDENCE FOLDER-4.png" class="lastevidence img-fluid lastevidence3" id=""
                                    alt="">
                        </div>
                    </div>


                    {{-- img no 04 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container">
                            {{-- <img src="/img/EVIDENCE FOLDER-7.png" class="firstevidence small-image small-image4 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-7.png" id="hover-image" class="hover-image img-fluid hover-image4"
                                    alt=""> --}}
                                <img src="/img/evidence/EVIDENCE FOLDER-7.png" id=""
                                    class=" img-fluid lastevidence44" alt="" data-value="44">
                        </div>
                    </div>

                </div>

                <div class="row">
                    {{-- img no 05 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER.png" id="firstevidence"
                                class="firstevidence small-image small-image5 img-fluid" alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER.png" id="hover-image" class="hover-image img-fluid hover-image5"
                                    alt="">
                                <img src="/img/evidence/EVIDENCE FOLDER.png" id="lastevidence"
                                    class="lastevidence lastevidence5 img-fluid" alt="">
                        </div>
                    </div>
                    {{-- img no 06 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER-2.png" class="firstevidence small-image small-image6 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-2.png" id="hover-image"
                                class="hover-image hover-image6 img-fluid" alt="">
                            <img src="/img/evidence/EVIDENCE FOLDER-2.png" id="lastevidence"
                                class="lastevidence lastevidence6 img-fluid" alt="">
                        </div>
                    </div>
                    {{-- img no 07 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER-5.png" class="firstevidence small-image small-image7 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-5.png" id="hover-image"
                                class="hover-image hover-image7 img-fluid" alt="">
                            <img src="/img/evidence/EVIDENCE FOLDER-5.png" id="lastevidence lastevidence5"
                                class="lastevidence lastevidence7 img-fluid" alt="">
                        </div>
                    </div>
                    {{-- img no 08 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER-8.png" class="firstevidence small-image small-image8 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-8.png" id="hover-image"
                                class="hover-image hover-image8 img-fluid" alt="">
                            <img src="/img/evidence/EVIDENCE FOLDER-8.png" id="lastevidence"
                                class="lastevidence lastevidence8 img-fluid" alt="" data-value="8">
                        </div>
                    </div>
                </div>
                <div class="row">
                    {{-- img no 09 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER-1.png" class="firstevidence small-image small-image9 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-1.png" id="hover-image"
                                class="hover-image hover-image9 img-fluid" alt="">
                            <img src="/img/evidence/EVIDENCE FOLDER-1.png" id="lastevidence"
                                class="lastevidence lastevidence9 img-fluid" alt="">
                        </div>
                    </div>
                    {{-- img no 10 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select">
                            <img src="/img/EVIDENCE FOLDER-3.png" class="firstevidence small-image small-image10 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-3.png" id="hover-image"
                                class="hover-image hover-image10 img-fluid" alt="">
                            <img src="/img/evidence/EVIDENCE FOLDER-3.png" id="lastevidence"
                                class="lastevidence lastevidence10 img-fluid" alt="">
                        </div>
                    </div>
                    {{-- img no 11 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container">
                            {{-- <img src="/img/EVIDENCE FOLDER-6.png" class="firstevidence small-image small-image11 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-6.png" id="hover-image"
                                class="hover-image hover-image11 img-fluid" alt=""> --}}
                            <img src="/img/evidence/EVIDENCE FOLDER-6.png" id=""
                                class="lastevidence111 img-fluid" alt="" data-value="111">
                        </div>
                    </div>
                    {{-- img no 12 --}}
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="image-container four_img_select" id="handInHandMatchBox">
                            <img src="/img/EVIDENCE FOLDER-9.png" class="firstevidence small-image small-image12 img-fluid"
                                alt="">
                                <img src="/img/selecter/EVIDENCE FOLDER-9.png" id="hover-image"
                                class="hover-image hover-image12 img-fluid" alt="">
                            <img src="/img/evidence/EVIDENCE FOLDER-9.png" id="lastevidence"
                                class="lastevidence lastevidence12 img-fluid" alt="" data-value="12">
                        </div>
                    </div>
                </div>

                <div class="col-md-12 text-center mt-5" id="NextPageLoad">
                    <button class="btn" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                        <img src="{{asset('img/buttons/D_submite_white.png')}}" class="img-fluid  btn1 text-center"
                    alt="" id="D_submite_white_2">
                        <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center" id="buttons_countine_2"
                            alt="">
                    </button>
                </div>



                        <div class="modal fade" id="newspaper_2" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                            data-keyboard="false">
                            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div class="p-5 mt-5">
                                        <h2 class="contact-img-header text-center mb-5 mt-5">Excellent Work, Inspector.</h2>

                                        <p class="contact-img-style text-center">
                                           The message on the matchbox proves that Sam Lima was the one minding the store when the delivery arrived. That puts him 
                                           at the hand in hand saloon on April 23rd - the day Bonito Gaito heard someone threatening John Amicon
                                        </p>


                                        <p class="contact-img-style text-center">This is brilliant work. Looks like we've got all we need to press forward with the case.</p>
                                        <p>YOU MAY NOW OPEN ENVELOPE A5</p>
                                        <button class="btn mb-3" >

                                    <img src="{{asset('img/buttons/d_back_site_white.png')}}" class="img-fluid  btn2 zoom" id="newsPaperBackUrl" alt="">
                                            
                                        </button>
                                    </div>
                                </div>
                                    <style>


                                        .modal-content {
                                        background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                                        background-repeat: no-repeat;
                                        background-size: cover;
                                        /*  background-position: center;
                                    background-size: auto;
                                        height: 100%; */
                                        }


                                        .modal-body {
                                            display: flex;
                                            flex-direction: column;
                                            align-items: center;
                                            justify-content: center;
                                            text-align: center;
                                            height: 100%;
                                            color: white
                                        }
                                    </style>
                                </div>
                            </div>
                        </div>
            {{-- News paper 2 end Modal --}}

                            {{-- almostCorrect2 statr --}}

                            <div class="modal fade" id="almostCorrect2" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                            data-keyboard="false">
                            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div class="p-5 mt-5 mb-5">
                                        <h2 class="contact-img-header text-center mb-5 mt-5">Almost....</h2>
                
                                        <p class="contact-img-style text-center mb-5">
                                            One of the pieces was correct...but the other wasn’t
                                        </p>
                
                
                                        <h4 class="contact-img-style text-center"></h4>
                                        <button class="btn mt-5 mb-5">
                                            <img src="{{asset('img/buttons/AUTO BUTTON-1.png')}}" class="img-fluid  btn2 zoom" id="buttons_image_tryagain" alt="">
                                        </button>
                                    </div>
                                </div>
                                    <style>
                
                
                                        .modal-content {
                                        background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                                        background-repeat: no-repeat;
                                        background-size: cover;
                                        /*  background-position: center;
                                       background-size: auto;
                                        height: 100%; */
                                        }
                
                
                                        .modal-body {
                                            display: flex;
                                            flex-direction: column;
                                            align-items: center;
                                            justify-content: center;
                                            text-align: center;
                                            height: 100%;
                                            color: white
                                        }
                                    </style>
                                </div>
                            </div>
                        </div>
                        {{--almostCorrect2 End --}}



                        {{-- Hmm.... 2 start main_3 --}}
                        <div class="modal fade" id="modalHmm_2" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
            data-keyboard="false">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body mb-4">
                        <div class="p-5 mt-5 mb-5">
                        <h2 class="contact-img-header text-center mb-5 mt-5">Hmm...</h2>

                        <p class="contact-img-style text-center mb-5">
                            Sorry inspector, that doesn’t look quite right.
                        </p>


                        <h4 class="contact-img-style text-center"></h4>
                        <button class="btn mt-5 mb-5" id="TryAgainHmWhite">
                            <img src="{{asset("img/buttons/d_try_again_white.png")}}" class="img-fluid  btn2 zoom" id="buttons_image_try_again_hmm_2_white" alt="">

                            <img src="/img/buttons/AUTO BUTTON-1.png" class="img-fluid  btn2 zoom" id="buttons_image_try_again_hmm_2" alt="">
                        </button>
                    </div>
                </div>
                    <style>


                        .modal-content {
                        background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                        background-repeat: no-repeat;
                        background-size: cover;
                        /*  background-position: center;
                       background-size: auto;
                        height: 100%; */
                        }


                        .modal-body {
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: center;
                            text-align: center;
                            height: 100%;
                            color: white
                        }
                    </style>
                </div>
            </div>
        </div>{{-- Hmm.....2 end  main_3--}}
                
</div>  {{-- End container card_main_3--}}
   








{{--Start Mian_4 --}}
{{-- Start container card_main_4--}}
<div class="container d-none" id="card_main_4">
    <div class="row text-center">
        <div class="col-md-12">
            <p class="p_main">
                Well done for getting this far, Inspector. Now for the last piece of the puzzle.There are two pairs
                of evidence that, when viewed Together, link Samuel Lima to the crime.
            </p>
            <h4 class="p_main">Can you select them both?</h4>
        </div>
    </div>

    <div class="row">
    {{-- img no 01 --}}
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="image-container last_foure">
            <img src="/img/EVIDENCE FOLDER-10.png" class="firstevidence small-image small-image1 img-fluid"
                alt="">
                <img src="/img/selecter/EVIDENCE FOLDER-10.png" id="hover-image"
                class="hover-image hover-image1 img-fluid" alt="">


            <img src="/img/evidence/EVIDENCE FOLDER-10.png" class="lastevidence lastevidence1 img-fluid"
                id="lastevidence" alt="">
        </div>
    </div>
            {{-- img no 02 --}}
            <!-- Add the remaining columns with adjusted column classes -->
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-11.png" class="firstevidence small-image small-image2 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-11.png" id="hover-image"
                            class="hover-image hover-image2 img-fluid" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-11.png" class="img-fluid lastevidence lastevidence2"
                            id="lastevidence" alt="">
                </div>
            </div>
            {{-- img no 03 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-4.png" class="firstevidence small-image small-image3 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-4.png" id="hover-image" class="hover-image img-fluid hover-image3"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-4.png" class="lastevidence img-fluid lastevidence3" id=""
                            alt="">
                </div>
            </div>


            {{-- img no 04 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-7.png" class="firstevidence small-image small-image4 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-7.png" id="hover-image" class="hover-image img-fluid hover-image4"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-7.png" id="lastevidence"
                            class="lastevidence img-fluid lastevidence4" alt="" data-value="4">
                </div>
            </div>

        </div>

        <div class="row">
            {{-- img no 05 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER.png" id="firstevidence"
                        class="firstevidence small-image small-image5 img-fluid" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER.png" id="hover-image" class="hover-image img-fluid hover-image5"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER.png" id="lastevidence"
                            class="lastevidence lastevidence5 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 06 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-2.png" class="firstevidence small-image small-image6 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-2.png" id="hover-image"
                        class="hover-image hover-image6 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-2.png" id="lastevidence"
                        class="lastevidence lastevidence6 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 07 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-5.png" class="firstevidence small-image small-image7 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-5.png" id="hover-image"
                        class="hover-image hover-image7 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-5.png" id="lastevidence lastevidence5"
                        class="lastevidence lastevidence7 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 08 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container">
                    {{-- <img src="/img/EVIDENCE FOLDER-8.png" class="firstevidence small-image small-image8 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-8.png" id="hover-image"
                        class="hover-image hover-image8 img-fluid" alt=""> --}}
                    <img src="/img/evidence/EVIDENCE FOLDER-8.png" 
                        class="lastevidence88 img-fluid" alt="" data-value="88">
                </div>
            </div>
        </div>
        <div class="row">
            {{-- img no 09 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-1.png" class="firstevidence small-image small-image9 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-1.png" id="hover-image"
                        class="hover-image hover-image9 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-1.png" id="lastevidence"
                        class="lastevidence lastevidence9 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 10 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-3.png" class="firstevidence small-image small-image10 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-3.png" id="hover-image"
                        class="hover-image hover-image10 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-3.png" id="lastevidence"
                        class="lastevidence lastevidence10 img-fluid" alt="">
                </div>
            </div>
            {{-- img no 11 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container last_foure">
                    <img src="/img/EVIDENCE FOLDER-6.png" class="firstevidence small-image small-image11 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-6.png" id="hover-image"
                        class="hover-image hover-image11 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-6.png" id="lastevidence"
                        class="lastevidence lastevidence11 img-fluid" alt="" data-value="11">
                </div>
            </div>
            {{-- img no 12 --}}
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="image-container" id="handInHandMatchBox">
                    {{-- <img src="/img/EVIDENCE FOLDER-9.png" class="firstevidence small-image small-image12 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-9.png" id="hover-image"
                        class="hover-image hover-image12 img-fluid" alt=""> --}}
                    <img src="/img/evidence/EVIDENCE FOLDER-9.png" id=""
                        class=" lastevidence122 img-fluid" alt="" data-value="122">
                </div>
            </div>
        </div>

        <div class="col-md-12 text-center mt-5" id="ButtonCountine4">
            <button class="btn" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                <img src="{{asset('img/buttons/D_submite_white.png')}}" class="img-fluid  btn1 text-center" id="buttons_countine_4_white"alt="">
                <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center" id="buttons_countine_4"alt="">
            </button>
        </div>



                <div class="modal fade" id="newspaper_4" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                    data-keyboard="false">
                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div class="p-5 mt-3">
                                <h2 class="contact-img-header text-center mb-5 mt-5">Excellent Work, Inspector.</h2>

                                <p class="contact-img-style text-center">
                                    We know from the Columbus Dispatch that Battaglia and Ventola were both suspected hitmen for the Black Hand mafia. The threatening letter gives John Amicon until the end of May to comply. Once that deadline passed, Sam Lima chose to contact both hitmen.              
                                </p>

                                <p class="contact-img-style text-center">Coincidence? Not Likely.</p>
                                <p class="contact-img-style text-center">This is brilliant work. Looks like we've got all we need to press forward with the case.</p>

                                <h4 class="contact-img-style_2 text-center">YOU MAY kNOW OPEN ENVELOPE A5</h4>
                                <button class="btn mb-4" >
                                    <img src="{{asset('img/buttons/d_back_site_white.png')}}" class="img-fluid  btn2 zoom" id="newsPaperBackHome"
                                        alt="">
                                       
                                </button>
                            </div>
                        </div>
                            <style>


                                .modal-content {
                                background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                                background-repeat: no-repeat;
                                background-size: cover;
                                /*  background-position: center;
                            background-size: auto;
                                height: 100%; */
                                }


                                .modal-body {
                                    display: flex;
                                    flex-direction: column;
                                    align-items: center;
                                    justify-content: center;
                                    text-align: center;
                                    height: 100%;
                                    color: white
                                }
                            </style>
                        </div>
                    </div>
                </div>
    {{-- News paper 4 end Modal --}}

                    {{-- almostCorrect4 statr --}}

                    <div class="modal fade" id="almostCorrect_4" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                    data-keyboard="false">
                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div class="p-5 mt-5 mb-5">
                                <h2 class="contact-img-header text-center mb-5 mt-5">Almost....</h2>
        
                                <p class="contact-img-style text-center mb-5">
                                    One of the pieces was correct...but the other wasn’t
                                </p>
        
        
                                <h4 class="contact-img-style text-center"></h4>
                                <button class="btn mt-5 mb-5" id="tryAgainLast">
                                    <img src="{{asset('img/buttons/d_try_again_white.png')}}" class="img-fluid  btn2 zoom" id="buttons_image_tryagain_4_white" alt="">
                                    <img src="{{asset('img/buttons/AUTO BUTTON-1.png')}}" class="img-fluid  btn2 zoom" id="buttons_image_tryagain_4" alt="">
                                </button>
                            </div>
                        </div>
                            <style>
        
        
                                .modal-content {
                                background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                                background-repeat: no-repeat;
                                background-size: cover;
                                /*  background-position: center;
                               background-size: auto;
                                height: 100%; */
                                }
        
        
                                .modal-body {
                                    display: flex;
                                    flex-direction: column;
                                    align-items: center;
                                    justify-content: center;
                                    text-align: center;
                                    height: 100%;
                                    color: white
                                }
                            </style>
                        </div>
                    </div>
                </div>
                {{--almostCorrect4 End --}}



                {{-- Hmm.... 4 start main_4 --}}
                <div class="modal fade" id="modalHmm_4" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
    data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="p-5 mt-5 mb-5">
                <h2 class="contact-img-header text-center mb-5 mt-5">Hmm...</h2>

                <p class="contact-img-style text-center mb-5">
                    Sorry inspector, that doesn’t look quite right.
                </p>


                <h4 class="contact-img-style text-center"></h4>
                <button class="btn mt-5 mb-5" id="tryAgainFour">
                    <img src="{{asset('img/buttons/d_try_again_white.png')}}" class="img-fluid  btn2 zoom" id="buttons_image_try_again_hmm_4_white" alt="">
                    <img src="/img/buttons/AUTO BUTTON-1.png" class="img-fluid  btn2 zoom" id="buttons_image_try_again_hmm_4" alt="">

                </button>
            </div>
        </div>
            <style>


                .modal-content {
                background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                background-repeat: no-repeat;
                background-size: cover;
                /*  background-position: center;
               background-size: auto;
                height: 100%; */
                }


                .modal-body {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    text-align: center;
                    height: 100%;
                    color: white
                }
            </style>
        </div>
    </div>
</div>{{-- Hmm.....4 end  main_4--}}
        
</div>  {{-- End container card_main_4--}}
{{--Start Mian_4 --}}






























</body>

</html>



<script>
    $(document).ready(function() {
        $("#card_main_2").show();
        $(".lastevidence").hide();
        $(".SOTBH_OverlayCard").hide();
        $("#evidence4").hide();
        $("#evidence3").hide();
        $("#case_1").click(function() {
            $("#card_main_1").hide();
            $("#card_main_2").show();
        });
        $("#buttons_countine").click(function() {
            $(".SOTBH_OverlayCard").show();
        });


    });

    const imageContainer = document.querySelector('.image-container');
    const smallImage = imageContainer.querySelector('.small-image');
    const hoverImage = imageContainer.querySelector('.hover-image');
    const lastEvidence = document.getElementById('evidence_10');
    const image = document.getElementById('SOTBH_OverlayCard');
    // Modify the image properties or perform actions
    smallImage.addEventListener('click', () => {

        smallImage.style.display = 'none';
        hoverImage.style.opacity = 1;
    });

    function openModal() {
        const modalContainer = document.getElementById('modalContainer');
        modalContainer.style.display = 'block';
    }

    // Function to close the modal
    // function closeModal() {
    //     const modalContainer = document.getElementById('modalContainer');
    //     modalContainer.style.display = 'none';
    // }
    $(document).ready(function() {

        var maxSelections = 2;
        var moreSelection = 4; 
        var selectedImages = [];

        var selected =  $(".image-container");
     
        $(".hover-image1").click(function() {

        if (selectedImages.length >= maxSelections ) {
            return; 
        } 

        $(".lastevidence1").show();
        $(".small-image1").hide();
        $(".hover-image1").hide();

  
});

    $(".lastevidence1").click(function() {
        
        $(".small-image1").toggle();
        $(".hover-image1").toggle();
        $(".lastevidence1").toggle();
    });

    $(".hover-image2").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence2").show();
        $(".small-image2").hide();
        $(".hover-image2").hide();
    });

    $(".lastevidence2").click(function() {
        $(".small-image2").toggle();
        $(".hover-image2").toggle();
        $(".lastevidence2").toggle();
    });

    $(".hover-image3").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence3").show();
        $(".small-image3").hide();
        $(".hover-image3").hide();
    });

    $(".lastevidence3").click(function() {
        $(".small-image3").toggle();
        $(".hover-image3").toggle();
        $(".lastevidence3").toggle();
    });

    $(".hover-image4").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence4").show();
        $(".small-image4").hide();
        $(".hover-image4").hide();
    });

    $(".lastevidence4").click(function() {
        $(".small-image4").toggle();
        $(".hover-image4").toggle();
        $(".lastevidence4").toggle();
    });

    $(".hover-image5").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence5").show();
        $(".small-image5").hide();
        $(".hover-image5").hide();
    });

    $(".lastevidence5").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".small-image5").toggle();
        $(".hover-image5").toggle();
        $(".lastevidence5").toggle();
    });

    $(".hover-image6").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence6").show();
        $(".small-image6").hide();
        $(".hover-image6").hide();
    });

    $(".lastevidence6").click(function() {
        $(".small-image6").toggle();
        $(".hover-image6").toggle();
        $(".lastevidence6").toggle();
    });

    $(".hover-image7").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence7").show();
        $(".small-image7").hide();
        $(".hover-image7").hide();
    });

    $(".lastevidence7").click(function() {
        $(".small-image7").toggle();
        $(".hover-image7").toggle();
        $(".lastevidence7").toggle();
    });
   
    $(".hover-image8").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
    $(".lastevidence8").show();
    $(".small-image8").hide();
    $(".hover-image8").hide();
    });

$(".lastevidence8").click(function() {
  $(".small-image8").toggle();
  $(".hover-image8").toggle();
  $(".lastevidence8").toggle();
});

    
    $(".hover-image9").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence9").show();
        $(".small-image9").hide();
        $(".hover-image9").hide();
    });

    $(".lastevidence9").click(function() {
        $(".small-image9").toggle();
        $(".hover-image9").toggle();
        $(".lastevidence9").toggle();
    });

    $(".hover-image10").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence10").show();
        $(".small-image10").hide();
        $(".hover-image10").hide();
    });

    $(".lastevidence10").click(function() {
        $(".small-image10").toggle();
        $(".hover-image10").toggle();
        $(".lastevidence10").toggle();
    });

    $(".hover-image11").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence11").show();
        $(".small-image11").hide();
        $(".hover-image11").hide();
    });

    $(".lastevidence11").click(function() {
        $(".small-image11").toggle();
        $(".hover-image11").toggle();
        $(".lastevidence11").toggle();
    });

    $(".hover-image12").click(function() {
        if (selectedImages.length >= maxSelections) {
         return;
         }
        $(".lastevidence12").show();
        $(".small-image12").hide();
        $(".hover-image12").hide();
    });

    $(".lastevidence12").click(function() {
        $(".small-image12").toggle();
        $(".hover-image12").toggle();
        $(".lastevidence12").toggle();
    });

      $(".only_two_select").click(function() {
        var $image = $(this);

        if ($image.hasClass("selected")) {

          var index = selectedImages.indexOf(this);
          if (index > -1) {
            selectedImages.splice(index, 1);
          }

          $image.removeClass("selected");
          $image.addClass("hidden");
        } else {
         
          if (selectedImages.length >= maxSelections ) 
          {
            // alert("You can only select up to " + maxSelections + " images.");
            return; 
          }else if(selectedImages.length >= maxSelections && !$(this).hasClass("selected")){
            // alert("You can only select up to " + maxSelectionsFour + " images.");
            return; 
          }

          selectedImages.push(this);
          $image.addClass("selected");
          $image.removeClass("hidden");

    

        }

       
        
      });
    });






    $(document).ready(function() {

     $('#buttons_countine').click(function() {

    var handInHandMatchBox = $(".lastevidence12:visible").data('value');
    var fuuitMarkt = $(".lastevidence8:visible").data('value');

    var outgoingReport = $(".lastevidence11:visible").data('value');
    var dispacthPageTwo = $(".lastevidence4:visible").data('value');


                if(outgoingReport === 11 && dispacthPageTwo === 4)
                {
                $('#matchbox2').modal('show');
                }
                 else if(outgoingReport === 11 && dispacthPageTwo === 4)
                {
                $('#matchbox2').modal('show');
                }

                else if (handInHandMatchBox === 12 && fuuitMarkt === 8) 
                {
                    $('#newspaper1').modal('show');

                    
                } //End esle if

                else if(fuuitMarkt === 8 || handInHandMatchBox === 12 || outgoingReport === 11 || dispacthPageTwo === 4)
                {
                    $('#almostCorrect').modal('show');

                    $("#buttons_image_almost").click(function(e){
                        // alert("modal hide");
                    $('#almostCorrect').modal('hide');

                    });

                }
                else if(outgoingReport === 11 && dispacthPageTwo === 4)
                {
                $('#matchbox2').modal('show');
                }

                

        else 
        {
              $('#exampleModalCente').modal('show');
              $("#buttons_image_try_again").click(function(e){
                        // alert("modal hide");
                    $('#exampleModalCente').modal('hide');

                    });
        }

    });
    });










// Conatiner main 3 start 

$("#matchboxtwoSelect").on('click' , function(e){
    
     var  maxSelected = 4;

     var  selectedImagesFour = [null, null];

    $('#matchbox2').modal('hide');

    $("#card_main_2").hide();

    $("#card_main_3").removeClass('d-none');
   

    // $(".lastevidence4").click(function() {
    //     $(".small-image4").toggle();
    //     $(".hover-image4").toggle();
    //     $(".lastevidence4").toggle();
    // });
   

    $(".notclickMe").prop("disabled", true);
    // document.getElementsByClassName("lastevidence11").disabled = true;
//    var a = document.getElementsByClassName("notclickMe").disabled = true;
// alert(a);
    // $(".lastevidence11").on('click',function() {
    //     alert("alert");
    //     // if (selectedImagesFour.length >= maxSelected){
    //     // return;
    //     // }
    //     console.log(selectedImagesFour.length);
    //     // alert("click me");
    //     $(".small-image11").hide();
    //     $(".hover-image11").hide();
    //     $(".lastevidence11").show();
    // });

  
    


    $(".hover-image1").click(function() {

        console.log(selectedImagesFour.length);
        
        if (selectedImagesFour.length >= maxSelected){
        return;
        }
        
    $(".lastevidence1").show();
    $(".small-image1").hide();
    $(".hover-image1").hide();

});


$(".hover-image2").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence2").show();
    $(".small-image2").hide();
    $(".hover-image2").hide();
});


$(".hover-image3").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence3").show();
    $(".small-image3").hide();
    $(".hover-image3").hide();
});

$(".hover-image5").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence5").show();
    $(".small-image5").hide();
    $(".hover-image5").hide();

});

$(".lastevidence5").click(function() {
    $(".small-image5").toggle();
    $(".hover-image5").toggle();
    $(".lastevidence5").toggle();
});



$(".hover-image6").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence6").show();
    $(".small-image6").hide();
    $(".hover-image6").hide();
});



$(".hover-image7").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence7").show();
    $(".small-image7").hide();
    $(".hover-image7").hide();
});


$(".hover-image8").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
$(".lastevidence8").show();
$(".small-image8").hide();
$(".hover-image8").hide();
});




$(".hover-image9").click(function() {
    console.log(selectedImagesFour.length);
    
    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence9").show();
    $(".small-image9").hide();
    $(".hover-image9").hide();
});



$(".hover-image10").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence10").show();
    $(".small-image10").hide();
    $(".hover-image10").hide();
});



$(".hover-image12").click(function() {
    console.log(selectedImagesFour.length);

    if (selectedImagesFour.length >= maxSelected){
        return;
        }
    $(".lastevidence12").show();
    $(".small-image12").hide();
    $(".hover-image12").hide();
});


$(".four_img_select").click(function() {

        var $image = $(this);

        if ($image.hasClass("selected")) {

          var index = selectedImagesFour.indexOf(this);
          if (index > -1) {
            selectedImagesFour.splice(index, 1);
          }

          $image.removeClass("selected");
          $image.addClass("hidden");
        } else {
         
          if (selectedImagesFour.length >= maxSelected) 
          {
            // alert("You can only select up to " + maxSelected + " images.");
            return; 
          }

          selectedImagesFour.push(this);
          $image.addClass("selected");
          $image.removeClass("hidden");

    

        }

      });




    // End Hide and show

   

    $('#buttons_countine_2').click(function() {

        
        
    var handInHandMatchBox = $(".lastevidence12:visible").data('value');

    var fuuitMarkt = $(".lastevidence8:visible").data('value');

    var outgoingReport = $(".lastevidence111:visible").data('value');
    var dispacthPageTwo = $(".lastevidence44:visible").data('value');


                if(outgoingReport === 111 && dispacthPageTwo === 44 && handInHandMatchBox === 12 && fuuitMarkt === 8)
                {
                      $('#newspaper_2').modal('show');
                }
                 else if((fuuitMarkt === 8 || handInHandMatchBox === 12) && (outgoingReport === 111 && dispacthPageTwo === 44))
                {
                    $('#almostCorrect2').modal('show');
                    $("#buttons_image_tryagain").click(function(e){
                    $('#almostCorrect2').modal('hide');
                    });
                }
                else 
                {
                            $('#modalHmm_2').modal('show');
                            $("#buttons_image_try_again_hmm_2").click(function(e){
                            $('#modalHmm_2').modal('hide');
                            });
                }

    });


}); //Next page button click end 

// Conatiner main 3 End 







































// Conatiner main 4 start 


$("#buttons_image_newsspaper_1").on('click' , function(e){
    
    var  maxSelecteded = 4;

    var  selectedImagesLastFour = [null, null];

    $('#newspaper1').modal('hide');

    $("#card_main_2").hide();

    $("#card_main_4").removeClass('d-none');

    // $(".lastevidence8").click(function() {
    //     $(".small-image8").toggle();
    //     $(".hover-image8").toggle();
    //     $(".lastevidence8").toggle();
    // });

    $(".notclickMe").prop("disabled", true);

    // $(".lastevidence12").click(function() {
    //     $(".small-image12").toggle();
    //     $(".hover-image12").toggle();
    //     $(".lastevidence12").toggle();
    // });

    // Start again last part

        // Now Start next page selections 


        $(".hover-image1").click(function() {

console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}

$(".lastevidence1").show();
$(".small-image1").hide();
$(".hover-image1").hide();

});


$(".hover-image2").click(function() {
console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}
$(".lastevidence2").show();
$(".small-image2").hide();
$(".hover-image2").hide();
});


$(".hover-image3").click(function() {
console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}
$(".lastevidence3").show();
$(".small-image3").hide();
$(".hover-image3").hide();
});



$(".hover-image4").click(function() {
        if (selectedImagesLastFour.length >= maxSelecteded) {
         return;
         }
        $(".lastevidence4").show();
        $(".small-image4").hide();
        $(".hover-image4").hide();
    });

$(".hover-image5").click(function() {
console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}
$(".lastevidence5").show();
$(".small-image5").hide();
$(".hover-image5").hide();

});

$(".lastevidence5").click(function() {
$(".small-image5").toggle();
$(".hover-image5").toggle();
$(".lastevidence5").toggle();
});



$(".hover-image6").click(function() {
console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}
$(".lastevidence6").show();
$(".small-image6").hide();
$(".hover-image6").hide();
});



$(".hover-image7").click(function() {
console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}
$(".lastevidence7").show();
$(".small-image7").hide();
$(".hover-image7").hide();
});


// $(".hover-image8").click(function() {
// console.log(selectedImagesLastFour.length);

// if (selectedImagesLastFour.length >= maxSelected){
// return;
// }
// $(".lastevidence8").show();
// $(".small-image8").hide();
// $(".hover-image8").hide();
// });




$(".hover-image9").click(function() {
console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}
$(".lastevidence9").show();
$(".small-image9").hide();
$(".hover-image9").hide();
});



$(".hover-image10").click(function() {
console.log(selectedImagesLastFour.length);

if (selectedImagesLastFour.length >= maxSelecteded){
return;
}
$(".lastevidence10").show();
$(".small-image10").hide();
$(".hover-image10").hide();
});


$(".hover-image11").click(function() {
        if (selectedImagesLastFour.length >= maxSelecteded) {
         return;
         }
        $(".lastevidence11").show();
        $(".small-image11").hide();
        $(".hover-image11").hide();
    });


// $(".hover-image12").click(function() {
// console.log(selectedImagesLastFour.length);

// if (selectedImagesLastFour.length >= maxSelected){
// return;
// }
// $(".lastevidence12").show();
// $(".small-image12").hide();
// $(".hover-image12").hide();
// });


$(".last_foure").click(function() {

var $image = $(this);

if ($image.hasClass("selected")) {

  var index = selectedImagesLastFour.indexOf(this);
  if (index > -1) {
    selectedImagesLastFour.splice(index, 1);
  }

  $image.removeClass("selected");
  $image.addClass("hidden");
} else {
 
  if (selectedImagesLastFour.length >= maxSelecteded) 
  {
    // alert("You can only select up to " + maxSelecteded + " images.");
    return; 
  }

  selectedImagesLastFour.push(this);
  $image.addClass("selected");
  $image.removeClass("hidden");



}

});






    // Start again last past


    $('#buttons_countine_4').click(function() {

        
    var handInHandMatchBox = $(".lastevidence122:visible").data('value');
    var fuuitMarkt = $(".lastevidence88:visible").data('value');

    var outgoingReport = $(".lastevidence11:visible").data('value');
    var dispacthPageTwo = $(".lastevidence4:visible").data('value');


                if(outgoingReport === 11 && dispacthPageTwo === 4 && handInHandMatchBox === 122 && fuuitMarkt === 88)
                {
                      $('#newspaper_4').modal('show');
                }
                 else if((fuuitMarkt === 88 && handInHandMatchBox === 122) && (outgoingReport === 11 || dispacthPageTwo === 4))
                {
                    $('#almostCorrect_4').modal('show');
                    $("#buttons_image_tryagain_4").click(function(e){
                    $('#almostCorrect_4').modal('hide');
                    });
                }
                else 
                {
                            $('#modalHmm_4').modal('show');
                            $("#buttons_image_try_again_hmm_4").click(function(e){
                            $('#modalHmm_4').modal('hide');
                            });
                }

    });

    


}); //Next page button click end 


 $("#newsPaperBackUrl , #newsPaperBackHome").click(function(){

    location.href = 'https://true-crime-bigpotato.zibly.co.uk';

 });







</script>
