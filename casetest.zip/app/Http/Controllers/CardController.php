<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CardController extends Controller
{

    public function caseone()
    {
       return view('cards.view1');
    }
    public function caseoneslecter()
    {
        return view("cards.selecters");

    }
    public function caseTwo()
    {
       return view('cards.casetwo.view2');
    }
}
