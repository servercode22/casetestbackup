
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Card</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(asset('css/casetwo.css')); ?>">

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
</head>

<body>
    <div>

        <div class="container-fluid mb-5 py-2" style="background-color: black;">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-6 text-center">
                    <img src="<?php echo e(asset('img/true_crime.svg')); ?>" alt="">
                </div>
                <div class="col-md-6 text-center">
                     <img src="<?php echo e(asset("img/OPERATION_BOGART.svg")); ?>" alt="">
                </div>
            </div>
        </div>



        <div class="container" id="mainCardhide">
            <div class="col-md-12 text-center">
                <b class="header">Find evidence that confirms all three painting are fakes - and not
                    originals.</b>
                <h3 class="mian_header">When you think you've got the right idea, pick a painting and submit your
                    evidence.</h3>
            </div>
            
            <div class="col-md-12">
                <div class="row justify-content-center">
                    <div class="col-lg-3 col-md-4 col-12">
                        
                        <div class="image-containerv mb-3 " id="leeHover" style="text-align:center;">

                    <img src="<?php echo e(asset('img/fake/FAKE_DREW_LEE.png')); ?>"  class="img-fluid d-none" id="showFakeDrewLee" data-value="1">
                    <img src="<?php echo e(asset('img/cas_two_imge/lee_hover.png')); ?>"  class="img-fluid" id="drweleeImage_Hover">
                    <img src="<?php echo e(asset('img/cas_two_imge/DREW_LEE.png')); ?>"  class="img-fluid" id="drweleeImageHover">

                    
                    


                    


                        </div>

                    </div>
                    
                    <div class="col-lg-3 col-md-4 col-12">

                        <div class="image-container mb-3" id="bakerHover">

                      <img src="<?php echo e(asset('img/fake/FAKE_RICHARD_BAKER.png')); ?>" class="img-fluid d-none" id="bakerSelectImage_fake" data-value="2">

                      <img src="<?php echo e(asset('img/cas_two_imge/baker_hover.png')); ?>" class=" img-fluid" id="bakerSelectImage_hover">

                      <img src="<?php echo e(asset('img/cas_two_imge/RICHARD_BAKER.png')); ?>" class=" img-fluid" id="bakerSelectImage">

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-12">
                        <div class="image-container" id="phyHover">
                        <img src="<?php echo e(asset('img/fake/FAKE_PHYLIS BROWNING.png')); ?>" class="img-fluid d-none" id="phylisImagehower_fake" data-value="3">

                        <img src="<?php echo e(asset('img/cas_two_imge/phy_hover.png')); ?>" class="img-fluid" id="phylisImagehower_2_hover">

                        <img src="<?php echo e(asset('img/cas_two_imge/PHYLIS_ROWNING.png')); ?>" class="img-fluid" id="phylisImagehower_2">

                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="col-md-12 text-center mt-5">
                <button class="btn d-none" id="AllFakeImages">
                    <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid"
                         id="AfterNowNextPageShowAllFakeImage_white">

                    <img src="<?php echo e(asset('img/buttons/AUTO BUTTON.png')); ?>" class="img-fluid  btn1 text-center"
                         alt="" id="AfterNowNextPageShowAllFakeImage">
                </button>

            </div>
        </div>
        


        

        

        <div class="container my_container_show justify-content-center" id="card_main_2" style="display: none">
            <div class="col-md-12 text-center">
                <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.</p>
            </div>

            <div class="row justify-content-center">
            <div class="col-lg-8 col-md-8 col-sm-8">
                <div class="image-container">
                    <img src="<?php echo e(asset('img/cas_two_imge/DREW_LEE_T.png')); ?>" alt="" class="w-100">
                </div>
            </div>
              </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 aftermodalclose_lee">
                <div class="image-container">
                    <p class="p_question">Q1: &nbsp;Which Part of Mr Lee's painting is the most
                        suspicious?</p>
                </div>
            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 beforemodalview_lee">
                <div class="image-container">
                    <p class="p_question">Q2: &nbsp;What's suspicious about it?</p>
                </div>
            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 beforemodalinputview_lee">
                <div class="image-container">
                    <p  class="p_question">Q2: &nbsp;What's suspicious about it?</p>
                </div>
            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 lastquesinputview_lee">
                <div class="image-container">
                    <p class="p_question">Q3: &nbsp;Name the painting where you've seen this
                        before</p>
                </div>
            </div>
            
            <div class="row justify-content-center aftermodalclose_lee">
                <div class="col-lg-4 col-md-4 col-sm-6">

                    <div class="image-container" id="signature">

                         <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON.png')); ?>" alt="" id="simple_signture" />

                         <img src="<?php echo e(asset('img/after_hover/singture_hover.png')); ?>" alt=""
                            class=" img-fluid" data-toggle="modal" data-target="#exampleModalCenter" data-value="1" id="signture_hover">

                    </div>

                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="colorHover">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-2.png')); ?>" class=" img-fluid" id="simple_color">

                        <img src="<?php echo e(asset('img/after_hover/color_hover.png')); ?>" class="img-fluid mt-2" data-value="2" id="theColoring">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="nameHover">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-4.png')); ?>" alt=""
                            class="img-fluid" id="simple_name">

                            <img src="<?php echo e(asset('img/after_hover/name_hover.png')); ?>" alt=""
                            class=" img-fluid mt-2" data-value="3" id="theName">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="shapesHover">

                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-1.png')); ?>" alt=""
                        class="img-fluid" id="simple_shapes">

                        <img src="<?php echo e(asset('img/after_hover/shape_hover.png')); ?>" alt=""
                            class="img-fluid mt-2" data-value="4" id="theShapes">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="materialHover">

                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-3.png')); ?>" alt=""
                            class="img-fluid"  id="simple_material">

                            <img src="<?php echo e(asset('img/after_hover/material_hover.png')); ?>" alt=""
                            class=" img-fluid mt-2" data-value="5" id="theMaterial">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="styleHover">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-5.png')); ?>" alt=""
                            class=" img-fluid" id="simple_style">

                            <img src="<?php echo e(asset('img/after_hover/style_hover.png')); ?>" alt=""
                            class=" img-fluid mt-2" data-value="6" id="theStyle">

                    </div>
                </div>

            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 beforemodalview_lee">
                <div class="image-container">
                  <div class="col-md-4">
                    <select class="form-control centered-placeholder" name="lee_option_1">
                      <option disabled selected value="">Select your answer</option>
                      <option value="it appears">It appears</option>
                      <option value="There are mistakes">There are mistakes</option>
                      <option value="it is faded">It is faded</option>
                      <option value="The style changes">The style changes</option>
                      <option value="There are parts mising">There are parts mising</option>
                    </select>
                  </div>
                  <div class="col-md-4">
                    <select class="form-control centered-placeholder" name="somewhere_else">
                      <option disabled selected value="">Select your answer</option>
                      <option value="At the end">at the end</option>
                      <option value="Near the beginning">near the beginning</option>
                      <option value="somewhere else">somewhere else</option>
                      <option value="In the worng place">in the worng place</option>
                      <option value="All over">all over</option>
                    </select>
                  </div>
                </div>
              </div>
             
             
              
              
              
        
            
            <div class="col-lg-12 col-md-12 col-sm-12 lastquesinputview_lee">
                <div class="image-container">
                    <div class="col-md-4 justify-content-center">
                        <input type="text" class="form-control centered-placeholder" name="Reflection"
                            id="reflection" placeholder="Type your answer here">
                    </div>
                </div>
            </div>
            <div class="col-md-12 text-center lastquesinputview_lee">
                <button class="btn" class="btn btn-primary" id="InputRef">

                    <img src="<?php echo e(asset('img/buttons/D_submite_white.png')); ?>" class="img-fluid"
                    id="submit__last_datalast_lee_evidence_white">

                    <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                        id="submit__last_datalast_lee_evidence">
                </button>
            </div>
            


            <div class="col-md-12 text-center beforemodalview_lee">
                <button class="btn" class="btn btn-primary" id="questionLee">
                    <img src="<?php echo e(asset('img/buttons/D_submite_white.png')); ?>" class="img-fluid text-center"
                    id="submit_lee_evidence_white">
                    <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                        id="submit_lee_evidence">
                </button>
            </div>



        </div>
        
        
        <div class="container my_containersecondimage_show_2 justify-content-center d-none">
            <div class="col-md-12 text-center">
                <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.
                </p>
            </div>

            <div class="row justify-content-center">

            <div class="col-lg-8 col-md-8 col-sm-8">
                <div class="image-container">

                    <img src="<?php echo e(asset('img/cas_two_imge/PHYLIS_BROWNIN_G_TITLE.png')); ?>" alt=""
                        class="w-100">
                </div>
            </div>
        </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">
                    <p style="color:black;" class="p_question">Q1: &nbsp;Which Part of Mrs Browning's painting is the
                        most
                        suspicious?</p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="signature_missphyish_2">

                          <img src="<?php echo e(asset('img/after_hover/singture_hover.png')); ?>" class=" img-fluid" id="the_signture_white_2">

                            <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON.png')); ?>" alt=""
                            class=" img-fluid" data-toggle="modal" data-target="#exampleModalCenter" id="the_signture_2">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="theColor2nd">

                        <img src="<?php echo e(asset('img/after_hover/color_hover.png')); ?>"   class=" img-fluid" id="the_color_white_2">

                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-2.png')); ?>" alt=""
                            class=" img-fluid" id="the_color_2">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6" >
                    <div class="image-container"id="theName2nd">

                        <img src="<?php echo e(asset('img/after_hover/name_hover.png')); ?>" class="img-fluid" id="the_name_white_2">

                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-4.png')); ?>" alt=""
                            class=" img-fluid" id="the_name_2">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="theShap2nd">

                        <img src="<?php echo e(asset('img/after_hover/shape_hover.png')); ?>"  class="img-fluid" id="the_shapes_white_2">


                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-1.png')); ?>" alt=""
                            class=" img-fluid mt-2" id="the_shapes_2">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="theMaterial2nd">

                        <img src="<?php echo e(asset('img/after_hover/material_hover.png')); ?>"
                        class=" img-fluid" id="the_material_white_2">

                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-3.png')); ?>" alt=""
                            class=" img-fluid mt-2" id="the_material_2">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="theStyle2nd">
                        <img src="<?php echo e(asset('img/after_hover/style_hover.png')); ?>" class=" img-fluid" id="the_style_white_2">

                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-5.png')); ?>" alt=""
                            class=" img-fluid mt-2" id="the_style_2">

                    </div>
                </div>

            </div>
            
        </div>
        

        

        <div class="container my_containersecondimage_show_questions_2 justify-content-center d-none">

            <div class="col-md-12 text-center">
                <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.
                </p>
            </div>


            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10 col-sm-10">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/PHYLIS_BROWNIN_G_TITLE.png')); ?>" alt=""
                            class="w-100">
                    </div>
                </div>
           </div>

            <div class="row justify-content-center">
                 <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="image-container">
                        <p class="p_question">Q2: &nbsp;What's suspicious about it?</p>
                    </div>
            <div class="image-container">
              <div class="col-md-4">
                <select class="form-control centered-placeholder" name="phy_brown_1">
                  <option disabled selected value="">Select your answer</option>
                  <option value="The artist was">The artist was</option>
                  <option value="The signature is">The signature is</option>
                  <option value="The Style is">The style is</option>
                  <option value="The thickness is">The thickness is</option>
                  <option value="The printing company was">The printing company was </option>
                  <option value="The pen was ">The pen was </option>
                  <option value="The ink is">The ink is </option>
                  <option value="The placement is">The placement is</option>
                </select>
              </div>
              <div class="col-md-4">
                <select class="form-control centered-placeholder" name="phy_brown_2">
                  <option disabled selected value="">Select your answer</option>
                  <option value="wrong">wrong</option>
                  <option value="in the wrong style">in the wrong style</option>
                   <option value="in poor condition">in poor condition</option>
                  <option value="the same in other places">the same in other places</option>
                  <option value="too heavy">too heavy</option>
                  <option value="the wrong colour">the wrong colour</option>
                  <option value="too light">too light</option>
                </select>
              </div>
            </div>
          </div>

          <div class="col-md-12 text-center">
            <button class="btn" id="SelectOptionBrwon">

                <img src="<?php echo e(asset('img/buttons/D_submite_white.png')); ?>" class="img-fluid  btn1 text-center"
                    id="submit_phy_brown_evidence_white">

                <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                    id="submit_phy_brown_evidence" alt="">
            </button>
        </div>

          </div>
        </div>
        

        

        <div class="container my_containersecondimage_show_input_question_2 justify-content-center d-none">

            <div class="col-md-12 text-center">
                <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.
                </p>
            </div>


            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/PHYLIS_BROWNIN_G_TITLE.png')); ?>" alt=""
                            class="w-100">
                    </div>
                </div>
           </div>

            <div class="row justify-content-center">
                 <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="image-container">
                        <p  class="p_question">Q3:Enter the evidence number that confirms the artist was in a poor condition?</p>
                 </div>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">
                    <div class="col-md-4 justify-content-center">

                        <input type="text" class="form-control centered-placeholder" name="B6A" id="B6A" placeholder="Type your answer here">

                    </div>
                </div>
            </div>

        
            <div class="row justify-content-center">
                <div class="col-md-12 text-center">
                    <button class="btn" id="inputBrown">
                        <img src="<?php echo e(asset('img/buttons/D_submite_white.png')); ?>" class="img-fluid  btn1 text-center"
                        id="submit__last_phy_brown_evidence_white" alt="">
                        <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                            id="submit__last_phy_brown_evidence" alt="">
                    </button>
                </div>
            </div>
          
        </div>

        

        

       





        
        <div class="container my_containerthirdimage_show justify-content-center d-none" id="card_main_2"
            style="display: none">
            <div class="col-md-12 text-center">
                <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.
                </p>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">

                    <img src="<?php echo e(asset('img/PERSON SELECTION/TITLE/RICHARD BAKER TITLE.png')); ?>" alt=""
                        class="w-100">
                </div>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">
                    <p class="p_question">Q1: &nbsp;Which Part of Mr Richard's painting is the
                        most
                        suspicious?</p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="signature_missphyish">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON.png')); ?>" alt=""
                            class=" img-fluid" data-toggle="modal" data-target="#exampleModalCenter">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-2.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-4.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-1.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-3.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-5.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>

            </div>
            <div class="col-md-12 text-center">
                <button class="btn" class="btn btn-primary">
                    <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn1 text-center" id="buttons_countine"
                        alt="">
                </button>
            </div>




        </div>
    </div>



                
                <div class="container my_container3rdimage_show_3 justify-content-center d-none">
                    <div class="col-md-12 text-center">
                        <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.
                        </p>
                    </div>
        
                    <div class="row justify-content-center">

                   
                    <div class="col-lg-8 col-md-8 col-sm-8">
                        <div class="image-container">
                            <img src="<?php echo e(asset('img/cas_two_imge/RICHARD_BAKER _TITLE.png')); ?>" alt=""
                                class="w-100">
                        </div>
                    </div>

                 </div>
        
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="image-container">
                            <p class="p_question">Q1: &nbsp;Which Part of Mr Richard's painting is the
                                most
                                suspicious?</p>
                        </div>
                    </div>

                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="image-container" id="signature_missphyish">

                                <img src="<?php echo e(asset('img/after_hover/singture_hover.png')); ?>" id="the_signture_white_3">

                                    <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON.png')); ?>" alt=""
                                    class=" img-fluid" data-toggle="modal" data-target="#exampleModalCenter" id="the_signture_3">
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="image-container" id="thecolor_3rd">

                                <img src="<?php echo e(asset('img/after_hover/color_hover.png')); ?>" id="the_color_white_3">

                                <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-2.png')); ?>" alt=""
                                    class=" img-fluid" id="the_color_3">
        
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="image-container" id="thename_3rd">
                                <img src="<?php echo e(asset('img/after_hover/name_hover.png')); ?>" id="the_name_white_3">

                                <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-4.png')); ?>" alt=""
                                    class=" img-fluid" id="the_name_3">
        
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="image-container" id="theshapes_3rd">

                                <img src="<?php echo e(asset('img/after_hover/shape_hover.png')); ?>" id="the_shape_white_3">

                                <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-1.png')); ?>" alt=""
                                    class=" img-fluid mt-2" id="the_shapes_3">
        
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="image-container" id="thematerial_3rd">
                                <img src="<?php echo e(asset('img/after_hover/material_hover.png')); ?>" id="the_material_white_3">
                                <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-3.png')); ?>" alt=""
                                    class=" img-fluid mt-2" id="the_material_3">
        
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="image-container" id="thestyle_3rd">
                                <img src="<?php echo e(asset('img/after_hover/style_hover.png')); ?>" id="the_style_white_3">
                                
                                <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-5.png')); ?>" 
                                    class=" img-fluid mt-2" id="the_style_3">
        
                            </div>
                        </div>
        
                    </div>
                  
             </div>
                
        

                

<div class="container my_container_baker_image_show_questions_3 justify-content-center d-none">

    <div class="col-md-12 text-center">
        <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.
        </p>
    </div>


    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-8 col-sm-8">
            <div class="image-container">
                <img src="<?php echo e(asset('img/cas_two_imge/RICHARD_BAKER _TITLE.png')); ?>" alt=""
                    class="w-100">
            </div>
        </div>
   </div>

    <div class="row justify-content-center">

         <div class="col-lg-12 col-md-12 col-sm-12">

                <div class="image-container">
                    <p class="p_question">Q2: &nbsp;What's suspicious about it?</p>
                </div>
        
                    <div class="image-container">
                    <div class="col-md-4">
                        <select class="form-control centered-placeholder" name="baker1">
                        <option disabled selected value="">Select your answer</option>
                        <option value="It uses paint">It uses paint</option>
                        <option value="It contains an object">It contains an object</option>
                        <option value="It's in a frame">It's in a frame</option>
                        <option value="It's printed on paper">It's printed on paper</option>
                        <option value="It includes a color">It includes a color</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select class="form-control centered-placeholder" name="baker2">
                        <option disabled selected value="">Select your answer</option>
                        <option value=" that the artist disliked"> that the artist disliked</option>
                         <option value="that didn't exist before">that didn't exist before</option>
                        <option value="that's too expensive">that's too expensive</option>
                        <option value="that's used somewhere else">that's used somewhere else</option>
                        <option value="that the artist had no access to">that the artist had no access to</option>
                        </select>
                    </div>
                    </div>
        </div>

        <div class="col-md-12 text-center">
            <button class="btn" class="btn btn-primary" id="submitRicherBaker">
                <img src="<?php echo e(asset("img/buttons/D_submite_white.png")); ?>" class="img-fluid  btn1 text-center"
                    id="submit_richer_baker_evidence_white" alt="">

                <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                    id="submit_richer_baker_evidence" alt="">
            </button>
        </div>
  </div>

</div>

                


        <div class="container my_container3rdimage_show_input_question_3 justify-content-center d-none">

            <div class="col-md-12 text-center">
                <p class="onPage">Find evidence that confirms all three painting are fakes - and not originals.
                </p>
            </div>


            <div class="row justify-content-center">
                <div class="col-lg-10 col-md-10 col-sm-10">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/RICHARD_BAKER _TITLE.png')); ?>" alt=""
                            class="w-100">
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="image-container">
                            <p class="p_question">Q3: What's the earliest year this painting could have been created?</p>
                    </div>
                </div>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">
                    <div class="col-md-4 justify-content-center">

                        <input type="text" class="form-control centered-placeholder" name="1975" id="1975" placeholder="Type your answer here">

                    </div>
                </div>
            </div>


            <div class="row justify-content-center">
                <div class="col-md-12 text-center">
                    <button class="btn" id="submitLastEvidence">

                        <img src="<?php echo e(asset('img/buttons/D_submite_white.png')); ?>" class="img-fluid  btn1 text-center"
                        id="submit__last_richer_baker_evidence_white" alt="">

                        <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                            id="submit__last_richer_baker_evidence" alt="">
                    </button>
                </div>
            </div>
        
        </div>


        
                



    



<div class="container d-none" id="brilliant_work">
    <div class="col-md-12 text-center">
        <b class="onPage">Brilliant work, Inspector. You've proven that each of the three paintings were fakes - just as we suspected.</b>
        <p class="onPage">There's no doubt that there's something shady going on at Good Plains Gallery.Now, we just need to prove that the Gallery were in on it from the beginning.
            We've called in a favour from the New Jersey Police department. They've sent two undercover detectives into the gallery to see if they could find anything interesting. Here's a short recording of their visit. Who knows - maybe you'll find something useful.</p>
    </div>
 
   
        <div class="row justify-content-center mb-4">
            <div class="col-lg-12 col-md-10 col-sm-6">
                <div class="image-container">
                    <img src="<?php echo e(asset('img/last.png')); ?>" alt="" class=" img-fluid">
                </div>
            </div>
        </div>

        <div class="row justify-content-center mb-5">
            <div class="col-lg-4 col-md-4 col-sm-6">
                <div class="image-container">
                    <button class="btn">

                    <img src="<?php echo e(asset('img/play.png')); ?>" alt=""
                        class="img-fluid" id="play_music">

                        <audio id="dummy_audio" controls class="d-none">
                            <source src="<?php echo e(asset('music/dummy.mp3')); ?>" type="audio/mpeg">
                          </audio>

                        </button>
                </div>
            </div>
        </div>

        <div class="row mb-5">

            <div class="col-lg-12 col-md-4 col-sm-6" style="text-align: center;">
            
                  <p class="onPage">Find further evidence that the Good Plains Gallery, were intentionally misleading their customers.</p>
                
            </div>

        </div>
    

    <div class="col-md-12 text-center">
        <button class="btn" id="FinalAllFakeContinueButton">
            <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid  btn1 text-center"
                id="buttons_countine_after_white" alt="">

                <img src="<?php echo e(asset('img/buttons/AUTO BUTTON.png')); ?>" class="img-fluid  btn1 text-center"
                id="buttons_countine_after" alt="">


        </button>
    </div>



</div>










<div class="container d-none" id="brilliant_work_2">
    <div class="col-md-12 text-center">
        <p class="onPage">Find further evidence that the Good Plains Gallerywere intentionally misleading their customers.</p>
    </div>
 
   
        <div class="row justify-content-center mb-4">
            <div class="col-lg-12 col-md-10 col-sm-6">
                <div class="image-container">
                    <img src="<?php echo e(asset('img/last.png')); ?>" alt="" class=" img-fluid">
                </div>
            </div>
        </div>


        <div class="row justify-content-center mb-1">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">
                  <p class="onPage">Which piece of evidence, when combined with the undercover recording, proves that Good Plains Gallery were intentionally lying to their customers?</p>
                </div>
            </div>
        </div>

        <div class="row justify-content-center mb-5">

            <div class="col-lg-4 col-md-4 col-sm-6" >
            
                <input type="text" class="form-control centered-placeholder" name="ChnageNameAfterLastPart"
                id="" placeholder="Type your answer here">
                
            </div>

        </div>
    
        <div class="col-md-12 text-center">
            <button class="btn" id="backToAudio">
    
                <img src="<?php echo e(asset('img/buttons/AUTO BUTTON-4.png')); ?>" class="img-fluid  btn1 text-center"
                id="back_page_white">
    
                <img src="<?php echo e(asset('img/buttons/AUTO BUTTON-4-hower.png')); ?>" class="img-fluid  btn1 text-center"
                    id="back_page" alt=""> 
                    
            </button>
        </div>

    <div class="col-md-12 text-center">
        <button class="btn" id="LastsubmiteInput">

            <img src="<?php echo e(asset('img/buttons/D_submite_white.png')); ?>" class="img-fluid  btn1 text-center"
            id="submite_for_input_last_part_white" alt="">

            <img src="<?php echo e(asset('img/buttons/AUTO BUTTON-2.png')); ?>" class="img-fluid  btn1 text-center"
                id="submite_for_input_last_part" alt="">
        </button>
    </div>



</div>









<div class="container d-none" id="brilliant_work_3">

        <div class="row justify-content-center mb-5">
            <div class="col-lg-12 col-md-10 col-sm-6">
                <div class="image-container">
                    <img src="<?php echo e(asset('img/last_case/OPERATION BOGART.svg')); ?>" alt="" class=" img-fluid">
                </div>
            </div>
        </div>


        <div class="row justify-content-center mb-5">
            <div class="col-lg-12 col-md-12 col-sm-6">
                <div class="image-container">
                  <p class="onPage">Excellent work, Detective. 
                    Thanks to you,we`ve managed to pull the plug on the whole Good Plains operation. Mr Lee, Mr Baker and Mrs Browning all send their thanks - as do hundreds of other hoodwinked customers</p>
                </div>
            </div>
        </div>


        <div class="row justify-content-center mb-5">
            <div class="col-lg-12 col-md-10 col-sm-6">
                <div class="image-container">
                    <img src="<?php echo e(asset('img/last_case/HOW IT HAPPENED.svg')); ?>" alt="" class=" img-fluid" />
                </div>
            </div>
        </div>

        <div class="row justify-content-center mb-5">

             <div class="col-lg-12 col-md-12 col-sm-6" >
            
               <p class="onPage">In 1991, Postal Inspector Jack Ellis lead a team of postal workers and undercover detectives to crack a billion dollar art forgery ring, lead by Leon Amiel. Over the years, Amiel had forged paintings and sent them through the US Postal System,passing them off as the real thing. 
The case required the purchase of 22 different counterfeit works, which were then analysed by detectives and renowned art experts. It all culminated in the seizure of over 100,000 supposed originals from artists like Salvador Dali, Joan Miro and Pablo Picasso. In the end, every piece was determined to be "bogus art".
         <b>Thus, the name - Operation Bogart.</b> </p>
                
            </div> 

        </div>
    

    <div class="col-md-12 text-center">
        <button class="btn">
            <img src="<?php echo e(asset('img/buttons/AUTO BUTTON-3.png')); ?>" class="img-fluid  btn1 text-center" id="BackToMainSide">
        </button>
    </div>



</div>








    

    <!-- mr lee Modal -->
    <div class="modal fade" id="signaturemodal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
            <div class="modal-content justify-content-center">
                <div class="modal-body mb-5 mt-4">
                    <div class="p-5 mt-5 mb-5 test">
                    <h4 class="h2_font_style mt-5">Correct !</h4>

                    <p class="p_main ">
                        There's something suspicious about the signature on Mr Lee's painting. What could to be...
                    </p>

                    <button class="btn mt-5 mb-5" id="MrLeeCountinu">

                        <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid countinues" id="buttons_image_white">

                        <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues"
                            id="buttons_image">
                    </button>
                    </div>
                </div>
                <style>
                    .modal-content {
                        background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                        background-repeat: no-repeat;
                        /* background-size: cover; */
                        /* background-size: cover; */
                        background-position: center;
                    }

                    .modal-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        height: 100%;
                        color: white
                    }
                </style>
            </div>
        </div>
    </div>


    <!-- mr lee after input Modal -->
    <div class="modal fade" id="inputmodallee" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
            <div class="modal-content justify-content-center">
                <div class="modal-body mb-5 mt-5">
                    <div class="p-5 mt-5 mb-5 test">
                    <h4 class="h2_font_style">CORRECT !</h4>

                    <p class="p_main mt-5">
                        That's it! We've definitely seen the signature somewhere else before. But where?
                    </p>

                    <button class="btn mt-5 mb-4" id="RightAnsCountineu">
                        <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid" id="addtolast_lee_white">
                        <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues"
                            id="addtolast_lee">
                    </button>
                    </div>
                </div>
                <style>
                    .modal-content {
                        background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                        background-repeat: no-repeat;
                        /* background-size: cover; */
                        /* background-position: center; */
                    }

                    .modal-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        height: 100%;
                        color: white
                    }
                </style>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="inputmodal_last_lee" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
        <div class="modal-content justify-content-center">
            <div class="modal-body ">
                <div class="p-5 mt-5 mb-5 test">
                <h4 class="h2_font_style mt-5 mb-5">BINGO !</h4>

                <p class="p_main">
                    Nova Oz never signed his name the same way twice,
                    but the same signature appears on both 'Reflection'
                    and 'Home at Last'.
                </p>
                <p class="p_main mb-5">
                    We known that 'Reflection' is a genuine painting,
                    because Nova Oz himself presented it to the gallery
                    which means Mr Lee's painting must be a fake.
                </p>


                <button class="btn" id="BingoMrLee">
                    <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid  btn2 zoom" id="newImagePageSelect_white" alt="">

                    <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom" id="newImagePageSelect" alt="">
                </button>
            </div>
            </div>
            <style>
                .modal-content {
                    background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                    background-repeat: no-repeat;
                    /* background-size: cover; */
                    /* background-position: center; */
                }

                .modal-body {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    text-align: center;
                    height: 100%;
                    color: white
                }
            </style>
        </div>
    </div>
</div>







<div class="modal fade" id="physllBrwonCorrect" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
        <div class="modal-content justify-content-center">
            <div class="modal-body ">
                <div class="p-5 mt-5 mb-5 test">
                <h4 class="h2_font_style mt-5 mb-5">BINGO !</h4>

                <p class="p_main">
                    Although Nova Oz was still able to paint, he became
                    incapable of writing this own name after 1979.
                </p>
                <p class="p_main mb-5">
                We Know that Cataclysm war created in the 80's, when Nova was no longer
                able to write his signature - which means that Mrs Browning a painting is
                (at least partially) a fake.
                </p>


                <button class="btn" id="LastModalBrown">
                    <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid  btn2 zoom" id="newImagePageSelectAfterphyBworn_white" alt="">

                    <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom" id="newImagePageSelectAfterphyBworn" alt="">

                </button>
            </div>
            </div>
            <style>
                .modal-content {
                    background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                    background-repeat: no-repeat;
                    /* background-size: cover; */
                    /* background-position: center; */
                }

                .modal-body {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    text-align: center;
                    height: 100%;
                    color: white
                }
            </style>
        </div>
    </div>
</div>





         <div class="modal fade" id="theWrongModal" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                data-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-body mb-4">
                            <div class="p-5 mt-5 mb-5">
                            <h2 class="p_main text-center mb-5 mt-5">HMM....</h2>
    
                            <p class="p_main text-center mb-5">
                                Sorry, Inspector. That doesn't look quite right.
                            </p>
    
    
                            <h4 class="contact-img-style text-center"></h4>
                            <button class="btn mt-5 mb-5" id="tryAgainHover">
                                <img src="<?php echo e(asset('img/buttons/d_try_again_white.png')); ?>" class="img-fluid  btn2 zoom" id="trygain_white" alt="">
                                <img src="/img/buttons/AUTO BUTTON-1.png" class="img-fluid  btn2 zoom" id="trygain" alt="">
                            </button>
                        </div>
                    </div>
                        <style>
    
    
                            .modal-content {
                                background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                            background-repeat: no-repeat;
                            background-size: cover;
                            /*  background-position: center;
                           background-size: auto;
                            height: 100%; */
                            }
    
    
                            .modal-body {
                                display: flex;
                                flex-direction: column;
                                align-items: center;
                                justify-content: center;
                                text-align: center;
                                height: 100%;
                                color: white
                            }
                        </style>
                    </div>
                </div>
            </div>







<div class="modal fade" id="the_corrent_Modal" tabindex="-1" role="dialog"
aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered modal-lg " role="document">
    <div class="modal-content justify-content-center">
        <div class="modal-body">
            <div class="p-5 mt-5 mb-5 test">
            <h4 class="h2_font_style mb-5 mt-5">CORRECT!</h4>
            <p class="p_main mb-5">
                This signture looks like the real deal, but something doesn't feel right.
            </p>
            <button class="btn mb-5 mt-5" id="TheCorrect2ndModal">

                <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid" id="the_corrent_go_white" alt="">

                <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid" id="the_corrent_go" alt="">

            </button>
        </div>
        </div>
        <style>
            .modal-content {
                background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                background-repeat: no-repeat;
                /* background-size: cover; */
                /* background-position: center; */
            }

            .modal-body {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
                height: 100%;
                color: white
            }
        </style>
    </div>
</div>
</div>






    <div class="modal fade" id="phyBrwonCorrectAnswer" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
        <div class="modal-content justify-content-center">
            <div class="modal-body">
                <div class="p-5 mt-5 mb-5 test">
                <h4 class="h2_font_style mb-5 mt-5">CORRECT!</h4>
                <p class="p_main mb-5">
                    Nova wasn't doing too wall at the time this was painted. Could that be a Clue?
                </p>
                <button class="btn mb-5 mt-5" id="correntphyBwornModal">
                    <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid" id="the_corrent_phyBworn_go_white" alt="">

                    <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid" id="the_corrent_phyBworn_go" alt="">
                </button>
            </div>
            </div>
            <style>
                .modal-content {
                    background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                    background-repeat: no-repeat;
                    /* background-size: cover; */
                    /* background-position: center; */
                }

                .modal-body {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    text-align: center;
                    height: 100%;
                    color: white
                }
            </style>
        </div>
    </div>
    </div>






<div class="modal fade" id="the_barkr_corrent_Modal" tabindex="-1" role="dialog"
aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered modal-lg " role="document">
    <div class="modal-content justify-content-center">
        <div class="modal-body">
            <div class="p-5 mt-5 mb-4 test">
            <h4 class="h2_font_style mb-5 mt-5">CORRECT!</h4>
            <p class="p_main mb-5">
                Something about the material just doesn't add up. But we'll need to be a bit more specific...
            </p>
            <button class="btn mb-5 mt-5" id="theCorrectBakerGo">
                <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid" id="the_corrent_baker_go_white" alt="">

                <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid" id="the_corrent_baker_go" alt="">
            </button>
        </div>
        </div>
        <style>
            .modal-content {
                background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                background-repeat: no-repeat;
                /* background-size: cover; */
                /* background-position: center; */
            }

            .modal-body {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
                height: 100%;
                color: white
            }
        </style>
    </div>
</div>
</div>









        <div class="modal fade" id="rechiredbakerCorrectAnswer" tabindex="-1" role="dialog"
                 aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
                <div class="modal-content justify-content-center">
                    <div class="modal-body">
                        <div class="p-5 mt-5 mb-5 test">
                        <h4 class="h2_font_style mb-5 mt-5">CORRECT!</h4>
                        <p class="p_main mb-5">
                            Of course! The paper it's printed on was made too recently. Something doesn't add up...
                        </p>
                        <button class="btn mb-5 mt-5" id="correntSecondAnswere">
                            <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid" id="the_corrent_second_answere_baker_go_white" alt="">

                            <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid" id="the_corrent_second_answere_baker_go" alt="">
                        </button>
                    </div>
                    </div>
                    <style>
                        .modal-content {
                            background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                            background-repeat: no-repeat;
                            /* background-size: cover; */
                            /* background-position: center; */
                        }

                        .modal-body {
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: center;
                            text-align: center;
                            height: 100%;
                            color: white
                        }
                    </style>
                </div>
            </div>
        </div>






<div class="modal fade" id="inputmodal_recherd_baker" tabindex="-1" role="dialog"
aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered modal-lg " role="document">
    <div class="modal-content justify-content-center">
        <div class="modal-body ">
            <div class="p-5 mt-5 mb-5 test">
            <h4 class="h2_font_style mt-5 mb-5">BINGO !</h4>

            <p class="p_main">
                According to the crime lab, Mr Baker's painting is printed on Ergone Stock paper.
            </p>
            <p class="p_main mb-5">
                This Company wasn't established until 1975, but we know that Nova Oz painted 'A
                Union' in 1968 - witch means Mr Baker's painting must be a fake.
            </p>


            <button class="btn" id="newpageCompate">
                <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid  btn2 zoom" id="newpageafterRecherdBaker_white" alt="">
                <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom" id="newpageafterRecherdBaker" alt="">

            </button>
        </div>
        </div>
        <style>
            .modal-content {
                background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                background-repeat: no-repeat;
                /* background-size: cover; */
                /* background-position: center; */
            }

            .modal-body {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
                height: 100%;
                color: white
            }
        </style>
    </div>
</div>
</div>






<div class="modal fade" id="lastPartModal" tabindex="-1" role="dialog"
aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-dialog-centered modal-lg " role="document">
    <div class="modal-content justify-content-center">
        <div class="modal-body">
            <div class="p-5 mb-5 mt-5 test">
            <h4 class="h2_font_style mb-5">BINGO !</h4>

            <p class="p_main ">
                No question about it - that gallery owner was describling
                Minerva Bloom's beloved painting, Stairway.
            </p>

            <p class="p_main ">
                We Know for a fact that Nova Oz sold his original to
                Minerva, not to the Good Plains Gallery. Sounds like
                they're trying to shift another fake painting as if it's
                an original again.
            </p>

            <p class="p_main ">
                This is great work, Detective. We should have all we need 
                to bring these Good Plains goons down for good.
            </p>
            <button class="btn" id="LastModalPart">
                <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid  btn2 zoom countinues"
                    id="atfterModalCountineu_white" alt="">

                <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues"
                    id="atfterModalCountineu" alt="">
            </button>
            </div>
        </div>
        <style>
            .modal-content {
                background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                background-repeat: no-repeat;
                /* background-size: cover; */
                /* background-size: cover; */
                background-position: center;
            }

            .modal-body {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
                height: 100%;
                color: white
            }
        </style>
    </div>
</div>
</div>










    <script>
        $(document).ready(function() {
            $('#mainCardhide').show();
            $(".my_container_show").hide();
            $(".my_containersecondimage_show").hide();
            $(".my_containerthirdimage_show").hide();
            $(".beforemodalinputview_lee").hide();
            $(".lastquesinputview_lee").hide();
            $("#case_2").click(function() {
                $('#mainCardhide').show();
                $("#case_2").hide();
                $("#card_main_1").hide()
            });
            $("#buttons_countine").click(function() {
                $(".SOTBH_OverlayCard").show();
            });


        });
        $('#drweleeImageHover').click(function() {
            $('#mainCardhide').hide();
            $(".my_container_show").show();
            $(".beforemodalview_lee").hide();
        });

      

        $("#BAKER").click(function() {
            $('#mainCardhide').hide();
            $(".my_containerthirdimage_show").show();
        });

        $(".countinues").click(function() {

            $('#signaturemodal').modal('hide');
            $(".aftermodalclose_lee").hide();
            $(".beforemodalview_lee").show();
            $(".aftermodalclose").hide();

        });
        $(document).ready(function() {
            $('#signature').click(function() {

                $('#signaturemodal').modal('show');

            });


            // work by zaheer start
            $("#submit_lee_evidence_white , #submit_lee_evidence").click(function() {
            const lee_option_1 = $("select[name='lee_option_1']").val();
            const somewhere_else = $("select[name='somewhere_else']").val();

            if (lee_option_1 === 'it appears' && somewhere_else === 'somewhere else') {
                $('#inputmodallee').modal('show');
            } else {
                $('#theWrongModal').modal('show');
                $("#trygain , #trygain_white").click(function() {
                $('#theWrongModal').modal('hide');
                });
            }
            });


            $("#submit_phy_brown_evidence").click(function() {
            const phy_brown_1 = $("select[name='phy_brown_1']").val();
            const phy_brown_2 = $("select[name='phy_brown_2']").val();

            if (phy_brown_1 === 'The artist was' && phy_brown_2 === 'in poor condition') {
                $('#phyBrwonCorrectAnswer').modal('show');
            } else {
                $('#theWrongModal').modal('show');
                $("#trygain , #trygain_white").click(function() {
                $('#theWrongModal').modal('hide');
                });
            }
            });
            // work by zaheer end


            $("#addtolast_lee").click(function() {
                $('#inputmodallee').modal('hide');
                $(".aftermodalclose_lee").hide();
                $(".beforemodalview_lee").hide();
                $(".aftermodalclose").hide();
                $(".lastquesinputview_lee").show();
            });



                    // work by zaheer start
            $("#submit__last_datalast_lee_evidence").click(function()
             {
                var reflectionValue = $("input[name='Reflection']").val();

                if (reflectionValue === 'Reflection' || reflectionValue === 'reflection') {
                $('#inputmodal_last_lee').modal('show');

                } else {
                    $('#theWrongModal').modal('show');
                $("#trygain , #trygain_white").click(function() {
                $('#theWrongModal').modal('hide');
                });
                }
            });
            

            $(".lastpageid").click(function() {

                $("#inputmodal_last_lee").modal('hide');
                
                // location.reload();
            });



            $("#the_corrent_phyBworn_go").click(function() 
            {
                // alert("now next page");

                $("#phyBrwonCorrectAnswer").modal('hide');

                $(".my_containersecondimage_show_questions_2").hide();

                $(".my_containersecondimage_show_input_question_2").removeClass('d-none');

            });


            $("#submit__last_phy_brown_evidence").click(function()
             {
                

                var phyBrown = $("input[name='B6A']").val();

                if (phyBrown === 'b6a' || phyBrown === 'B6A') {

                $('#physllBrwonCorrect').modal('show');

                } else {
                    $('#theWrongModal').modal('show');
                $("#trygain , #trygain_white").click(function() {
                $('#theWrongModal').modal('hide');
                });
                }
            });





            $("#newImagePageSelectAfterphyBworn").click(function(){


                $('#physllBrwonCorrect').modal('hide');

                $(".my_containersecondimage_show_input_question_2").hide();

                $('#mainCardhide').show();
                
                $("#phylisImagehower_2").addClass("d-none");

                $("#phylisImagehower_2_hover").addClass("d-none");

                $("#phylisImagehower_fake").removeClass("d-none");

              

            });

            
          
});

        

// ************Start work zaheer***************

const the_coloring = $('#theColoring').data('value');
const the_name = $('#theName').data('value');
const the_shapes = $('#theShapes').data('value');
const the_material = $('#theMaterial').data('value');
const the_style = $('#theStyle').data('value');

    $('#theColoring').click(function() {

    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });


    $('#theName').click(function() {
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });

    $('#theShapes').click(function() {
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });

    $('#theMaterial').click(function() {
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });

    $('#theStyle').click(function() {
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });


          $('#the_signture_2').click(function() {
           
           $('#the_corrent_Modal').modal('show');
  
           $("#the_corrent_go").click(function(){
  
           $('#the_corrent_Modal').modal('hide');

          $(".my_containersecondimage_show_2").hide();

           $(".my_containersecondimage_show_questions_2").removeClass("d-none");

  
            });
  
           });


















    // Second Image Working start 

    $("#newImagePageSelect , #newImagePageSelect_white").on("click", function(){

            $("#inputmodal_last_lee").modal('hide');
            // $("#mainCardhide").hide();
            $("#mainCardhide").show();

            $("#drweleeImageHover").addClass("d-none");

            $("#drweleeImage_Hover").addClass("d-none");

            $("#showFakeDrewLee").removeClass("d-none");

            $("#card_main_2").hide();

        });
        
        // PhySical Drown 

         $("#phylisImagehower_2").click(function() {

         $("#mainCardhide").hide();

         $(".my_containersecondimage_show_2").removeClass('d-none');
        
    
        
        //Show Questions

         $('#the_color_2').click(function() {
        
            $('#theWrongModal').modal('show');
        
            $("#trygain , #trygain_white").click(function(){
                $('#theWrongModal').modal('hide');
            });
    
        });

    $('#the_name_2').click(function() {
        
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });



    $('#the_shapes_2').click(function() {
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });

    $('#the_material_2').click(function() {
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });

    $('#the_style_2').click(function() {
    $('#theWrongModal').modal('show');

    $("#trygain , #trygain_white").click(function(){
        $('#theWrongModal').modal('hide');
    });

    });

    });



    // 3rd Image select 

    $("#bakerSelectImage").click(function(){

        $('#mainCardhide').hide();

        $(".my_container3rdimage_show_3").removeClass('d-none');

                        $('#the_color_3').click(function() {
                        
                        $('#theWrongModal').modal('show');
                    
                        $("#trygain , #trygain_white").click(function(){
                            
                            $('#theWrongModal').modal('hide');
                        });

                    });

                $('#the_name_3').click(function() {
                    
                $('#theWrongModal').modal('show');

                $("#trygain , #trygain_white").click(function(){
                    $('#theWrongModal').modal('hide');
                });

                });



                $('#the_shapes_3').click(function() {
                $('#theWrongModal').modal('show');

                $("#trygain , #trygain_white").click(function(){
                    $('#theWrongModal').modal('hide');
                });

                });

                $('#the_signture_3').click(function() {
                $('#theWrongModal').modal('show');

                $("#trygain , #trygain_white").click(function(){

                    $('#theWrongModal').modal('hide');
                });

                });

                $('#the_style_3').click(function() {
                $('#theWrongModal').modal('show');

                $("#trygain , #trygain_white").click(function(){
                    $('#theWrongModal').modal('hide');
                });

                });

    });


    $('#the_material_3').click(function() {

           $('#the_barkr_corrent_Modal').modal('show');
  
           $("#the_corrent_baker_go , #the_corrent_baker_go_white").click(function(){
  
           $('#the_barkr_corrent_Modal').modal('hide');

           $(".my_container3rdimage_show_3").hide();

           $(".my_container_baker_image_show_questions_3").removeClass("d-none");

            });
  
           });



           $("#submit_richer_baker_evidence , #submit_richer_baker_evidence_white").click(function() {
            // alert("assa");
            const baker_1 = $("select[name='baker1']").val();
            const baker_2 = $("select[name='baker2']").val();

            if (baker_1 === "It's printed on paper" && baker_2 === "that didn't exist before") {
            
                $('#rechiredbakerCorrectAnswer').modal('show');
            } else {
                $('#theWrongModal').modal('show');
                $("#trygain , #trygain_white").click(function() {
                $('#theWrongModal').modal('hide');
                });
            }
            });


            $("#the_corrent_second_answere_baker_go , #the_corrent_second_answere_baker_go_white").click(function() 
            {
                // alert("now next page");

                $("#rechiredbakerCorrectAnswer").modal('hide');

                $(".my_container_baker_image_show_questions_3").hide();

                $(".my_container3rdimage_show_input_question_3").removeClass('d-none');

            });


            $("#submit__last_richer_baker_evidence").click(function()
             {
                var reflectionValue = $("input[name='1975']").val();

                if (reflectionValue === '1975') {

                $('#inputmodal_recherd_baker').modal('show');

                } else 
                {
                    $('#theWrongModal').modal('show');
                $("#trygain , #trygain_white").click(function() {
                $('#theWrongModal').modal('hide');
                });
                }
            });


            $("#newpageafterRecherdBaker").click(function(){
             
                $('#inputmodal_recherd_baker').modal('hide');

                $(".my_container3rdimage_show_input_question_3").hide();

                $("#mainCardhide").show();

                $('#bakerSelectImage').addClass('d-none');
                $('#bakerSelectImage_hover').addClass('d-none');

                $('#bakerSelectImage_fake').removeClass('d-none');


            });


            $("#AfterNowNextPageShowAllFakeImage").click(function(){

                $("#mainCardhide").hide();

                $("#brilliant_work").removeClass("d-none");

            });

            $("#buttons_countine_after").click(function(){

                $("#brilliant_work").hide();

                $("#brilliant_work_2").removeClass("d-none");

                });




    $("#submite_for_input_last_part").click(function(){

     
     var reflectionValue = $("input[name='ChnageNameAfterLastPart']").val();

            if (reflectionValue === 'Stairway' || reflectionValue === 'stairway') {

            $("#lastPartModal").modal('show');

            } else 
            {
                $('#theWrongModal').modal('show');
            $("#trygain , #trygain_white").click(function() {
            $('#theWrongModal').modal('hide');
            });
            }
            
            

        $("#atfterModalCountineu").click(function(){

             $("#lastPartModal").modal('hide');

             $("#brilliant_work_2").hide();

              $("#brilliant_work_3").removeClass("d-none");
        });


        $("#BackToMainSide").click(function() 
        {
            window.location.href = 'https://true-crime-bigpotato.zibly.co.uk';
        });

    });


    $("#back_page").click(function() 
        {
          
            $('#brilliant_work_2').addClass('d-none');

            $('#brilliant_work').css('display','block');
            
        });


var fakeImages = ['#drweleeImageHover', '#bakerSelectImage', '#phylisImagehower_2'];
var allClicked = false;

var clickedCount = 0;

fakeImages.forEach(function(imageSelector, index) {
  $(imageSelector).on('click', function() {
    clickedCount++;
   console.log("click on" , imageSelector);
    if (clickedCount === fakeImages.length) {
      allClicked = true;
      $("#AllFakeImages").removeClass("d-none");

    }
  });
});


    var playButton = document.getElementById("play_music");
    var audioElement = document.getElementById("dummy_audio");

        var countinePlayStop = document.getElementById("buttons_countine_after");
        
    playButton.addEventListener("click", function() {
        // if (audioElement.paused) {
            audioElement.play();
        // } else {
        //     audioElement.pause();
        // }
    });
    
     countinePlayStop.addEventListener("click", function() {
            audioElement.pause();
    });
   
    </script>
</body>

</html>
















<?php /**PATH /home/thelogix/casetest.crossdevlogix.com/resources/views/cards/casetwo/view2.blade.php ENDPATH**/ ?>