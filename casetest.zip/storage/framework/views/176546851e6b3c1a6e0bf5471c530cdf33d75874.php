<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Card</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="css/card1.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
</head>

<body>
    <div class="container-fluid" id="card_main_1">
        <div class="container-fluid">
            <div class="col-md-12 text-center">
                <p>Well done for getting this far, Inspector.Now for the last piece of the puzzle.</p>
                <p>There are two pairs of evidence that,when viewed Together, link Samuel Lima to the crime</p>
                <h4>Can you Select them both</h4>

            </div>
            <div class="row">
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
                <div class="col-md-3">
                    <img src="/img/EVIDENCE FOLDER-1.png" alt="">

                </div>
            </div>

        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\cardsprojectsmub\resources\views/cards/selecters.blade.php ENDPATH**/ ?>