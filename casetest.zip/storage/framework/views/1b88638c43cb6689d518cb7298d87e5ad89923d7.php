 <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Card</title>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
            integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

        <link rel="stylesheet" href="<?php echo e(asset('css/casethree.css')); ?>">

        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
            integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
        </script>
    </head>

    <body>
        <div>

            <div class="container-fluid mb-5 py-2" style="background-color: black;">
                <div class="row justify-content-center align-items-center">
                    <div class="col-md-8">
                        <img src="<?php echo e(asset('img/true_crime.svg')); ?>" alt="">
                    </div>
                </div>
            </div>



            <div class="container" id="mian_container_hide_show">
                <div class="col-md-12 text-center">
                    <b class="main_header_part">Feeling Stuck?</b>
                    <h3 class="mian_header mt-5">If you're hitting a dead end, try some of these clues out. They might just point you in the right direction.</h3>
                </div>
                
                <div class="col-md-12 col-sm-12" style="text-align: center;">
                    <div class="row justify-content-center">

                        <div class="col-lg-4 col-md-4 col-sm-12">

                <div class="image-container mb-3" id="BLACKHAND">
                    
                            <img src="<?php echo e(asset('img/case_three/B_white.png')); ?>" class="img-fluid" id="case_one_white" />

                            <img src="<?php echo e(asset('img/case_three/B_1.png')); ?>" class="img-fluid" id="case_one" />

                </div>

                        </div> 
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="image-container mb-3" id="OPRATION">
                                <img src="<?php echo e(asset('img/case_three/BOGART_white.png')); ?>" class=" img-fluid"  id="case_two_white">
                                <img src="<?php echo e(asset('img/case_three/B_2.png')); ?>" class=" img-fluid"  id="case_two">

                            </div>
                        </div>
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="image-container" id="PARADISE">
                                    <img src="<?php echo e(asset('img/case_three/P_white.png')); ?>"class=" img-fluid" id="case_three_white">
                                    <img src="<?php echo e(asset('img/case_three/P_3.png')); ?>" class=" img-fluid" id="case_three">
                                </div>
                            </div>
                    </div>
                </div>

            
            </div>
            










                <div class="container d-none" id="Story_of_the_black_hand">

                    <div class="col-md-12 text-center mb-5">
                        <b class="main_header_part">Feeling Stuck?</b>
                        <!--<h3 class="mian_header">If your hitting a dead end, try some of these clues out.They might just point you in the right direction.</h3>-->
                    </div>
                    
                    
                        <div class="row justify-content-center">
                            <div class="col-lg-12 col-md-12 col-sm-12">

                                <p class="p_main point_1" >
                                    1. Don’t be discouraged if all three suspects have convincing alibis. One of them doesn’t quite add up.
                                </p>
            
                                <p class="p_main d-none point_2">
                                    2. Take another look at the letter from Robbie Watts. There might be some important information you overlooked.
                                </p>
            
                                <p class="p_main d-none point_3">
                                    3. Are we 100% sure where the letter was sent from? It could’ve been sent from anywhere in the country — not just Ohio.
                                </p>
            
                                <p class="p_main d-none point_4">
                                    4. Sounds like there was some pretty shady stuff going on at Plum Street. What was going on?
                                </p>
            
                                <p class="p_main d-none point_5">
                                    5. Look through the names mentioned in the Columbus Dispatch. Who do we know that’s connected to the Black Hand mafia… and are they connected with any of our suspects?
                                </p>
                            </div>

                            <div class="col-lg-12 col-md-12 col-sm-12 text-center">

                                <button class="btn mt-5 mb-5" id="SOTBH">

                            <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid btn2 zoom countinues" id="BlackHandCounite_white">

                            <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues" id="BlackHandCounite">
                            
                             <img src="<?php echo e(asset('img/buttons/d_back_site_white.png')); ?>" class="img-fluid d-none" id="Black_to_home_1">


                                </button>
                        
                        </div>

                    </div>
                    
                </div>
        


        


            <div class="container d-none" id="opration_bogart">

                <div class="col-md-12 text-center mb-5">
                    <b class="main_header_part">Feeling Stuck?</b>
                    <!--<h3 class="mian_header">If your hitting a dead end, try some of these clues out.They might just point you in the right direction.</h3>-->
                </div>
                
                
                    <div class="row justify-content-center">
                        <div class="col-lg-12 col-md-12 col-sm-12">

                            <p class="p_main point_1">
                               1. The Dawn Ceremony Museum says some of Nova’s paintings are on loan to the Good Plains Gallery maybe there’s someone there who can help?
                            </p>
            
                            <p class="p_main d-none point_2">
                               2. Ergone Stock? Where might you have seen that before
                            </p>
            
                            <p class="p_main d-none point_3">
                               3. This paper company really feels like the big time. I wonder how long they’ve been in business for?
                            </p>
            
                            <p class="p_main d-none point_4">
                                4. Cataclysm sure looks like one of Nova’s right down to the signature. But something’s off.
                            </p>
            
                            <p class="p_main d-none point_5">
                                5. According to his daughter,Nova hardly wrote to anyone in his final years even his closest friends. Why could that be?
                            </p>
                        </div>

                        <div class="col-lg-12 col-md-12 col-sm-12 text-center">

                            <button class="btn mt-5 mb-5">

                        <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid btn2 zoom countinues" id="ModalOneCounite_1_white">

                        <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues"
                                id="ModalOneCounite_1">
                                
                    <img src="<?php echo e(asset('img/buttons/d_back_site_white.png')); ?>" class="img-fluid d-none" id="Black_to_home_2">


                            </button>
                    
                    </div>
                </div>
            </div>
            




            <div class="container d-none" id="Gold_in_paradise">

                <div class="col-md-12 text-center mb-5">
                    <b class="main_header_part">Feeling Stuck?</b>
                    <!--<h3 class="mian_header">If your hitting a dead end, try some of these clues out.They might just point you in the right direction.</h3>-->
                </div>
                
                
                    <div class="row justify-content-center">
                        <div class="col-lg-12 col-md-12 col-sm-12">

                            <p class="p_main point_1" >
                                1. Find the right time for video cameras — distance from one post office to another.
                            </p>
                
                            <p class="p_main d-none point_2">
                                2. Check other angles — Who would have them.
                            </p>
                
                            <p class="p_main d-none point_3">
                                3 .Mail carriers can learn all sorts of secrets about a person. Who might know more about this “Anne Anderson”?
                            </p>
                
                            <p class="p_main d-none point_4">
                                4. Got all the details from the IOM? Maybe you should try picking up the phone.
                            </p>
                
                            <p class="p_main d-none point_5">
                                5. Sometimes, the best way to launder money is to trade it for something else. Something shiny.
                            </p>
                
                            <p class="p_main d-none point_6">
                               6. That lady really loved her Caesar salads. She even based a secret code around it.
                            </p>

                        </div>

                        <div class="col-lg-12 col-md-12 col-sm-12 text-center">

                            <button class="btn mt-5 mb-5">

                        <img src="<?php echo e(asset('img/buttons/D_continue.png')); ?>" class="img-fluid btn2 zoom countinues" id="ModalOneCounite_2_white">

                        <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues"
                        id="ModalOneCounite_2" >
                        
                        <img src="<?php echo e(asset('img/buttons/d_back_site_white.png')); ?>" class="img-fluid d-none" id="Black_to_home_3">


                            </button>
                    
                    </div>
                </div>
            </div>
    

    









        <script>

    // ******************************Story_of_the_black_hand*********************************


 var divCount = 1;

  $("#case_one, #case_one_white").click(function() {
  $("#mian_container_hide_show").addClass('d-none');
  $("#Story_of_the_black_hand").removeClass('d-none');
  divCount = 1;
  showPoints(divCount);
  $("#BlackHandCounite, #BlackHandCounite_white").removeClass('d-none');
});

$("#BlackHandCounite, #BlackHandCounite_white").on('click', function() {
  divCount++;
  showPoints(divCount);
  if (divCount >= 5) {
    divCount = 1;

    $("#Black_to_home_1").removeClass('d-none');
    $("#BlackHandCounite, #BlackHandCounite_white").addClass('d-none');
    
  }
});

$("#Black_to_home_1").click(function() {
  $("#mian_container_hide_show").removeClass('d-none');
  $("#Story_of_the_black_hand").addClass('d-none');
  $("#Black_to_home_1").addClass('d-none');

  hidePoints(5);
  $("#BlackHandCounite, #BlackHandCounite_white").removeClass('d-none');
});

function showPoints(count) {
  for (var i = 1; i <= count; i++) {
    $(".point_" + i).removeClass("d-none");
  }
}

function hidePoints(count) {
  for (var i = count; i >= 1; i--) {
    $(".point_" + i).addClass("d-none");
  }
}








    // **********************opration_bogart*********************************

 var divCount = 1;

    $("#case_two , #case_two_white").click(function() {
    $("#mian_container_hide_show").addClass('d-none');
    $("#opration_bogart").removeClass('d-none');
    divCount = 1;
    showPoints(divCount);
    $("#ModalOneCounite_1_white, #ModalOneCounite_1").removeClass('d-none');

    });

    $("#ModalOneCounite_1, #ModalOneCounite_1_white").on('click', function() {
    divCount++;
    showPoints(divCount);
    if (divCount >= 5) {
        divCount = 1;

        $("#Black_to_home_2").removeClass('d-none');
        $("#ModalOneCounite_1_white, #ModalOneCounite_1").addClass('d-none');

    }
    });


    $("#Black_to_home_2").click(function() {
$("#mian_container_hide_show").removeClass('d-none');
        $("#opration_bogart").addClass('d-none');
  $("#Black_to_home_2").addClass('d-none');

  hidePoints(5);
  $("#ModalOneCounite_1_white, #ModalOneCounite_1").removeClass('d-none');
});

    function showPoints(count) {
    for (var i = 1; i <= count; i++) {
        $(".point_" + i).removeClass("d-none");
    }
    }

    function hidePoints(count) {
    for (var i = count; i >= 1; i--) {
        $(".point_" + i).addClass("d-none");
    }
    }



    // ******************************Gold_in_paradise******************************************
   var divCount = 1;
    var totalPoints = 6;

    $("#case_three , #case_three_white").click(function() {
    $("#mian_container_hide_show").addClass('d-none');
    $("#Gold_in_paradise").removeClass('d-none');
    divCount = 1;
    showPoints(divCount);
    $("#ModalOneCounite_2, #ModalOneCounite_2_white").removeClass('d-none');
    });

    $("#ModalOneCounite_2, #ModalOneCounite_2_white").on('click', function() {
    divCount++;
    showPoints(divCount);
    if (divCount >= 6) {
        divCount = 1;


        $("#Black_to_home_3").removeClass('d-none');
        $("#ModalOneCounite_2_white, #ModalOneCounite_2").addClass('d-none');
        
    }

    });

    $("#Black_to_home_3").click(function() {
  $("#mian_container_hide_show").removeClass('d-none');
        $("#Gold_in_paradise").addClass('d-none');
      
  $("#Black_to_home_3").addClass('d-none');

  hidePoints(6);
  $("#ModalOneCounite_1_white, #ModalOneCounite_1").removeClass('d-none');
});


    function showPoints(count) {
    $(".p_main").addClass("d-none");
    for (var i = 1; i <= count; i++) {
        $(".point_" + i).removeClass("d-none");
    }
    if (count === totalPoints) {
        $(".point_1").removeClass("d-none");
    }
    }
    

        </script>
    </body>

    </html>


<?php /**PATH /home/thelogix/casetest.crossdevlogix.com/resources/views/cards/casethree/view3.blade.php ENDPATH**/ ?>