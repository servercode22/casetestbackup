
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Card</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="css/card1.css">
    <link href="https://fonts.cdnfonts.com/css/lorem-ipsum" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>


    <div class="container"  id="card_main_1">
        <div class="row align-items-center" style="height: 100vh;">
          <div class="col-md-12 d-flex justify-content-center">
            <div class="background-image-container">

                <img src="/img/BLACK HAND.png" class="img-fluid align-self-center" id="case_1">

            </div>
          </div>
        </div>
    </div>




    




    <div class="col-md-12" id="card_main_2">
        <div class="containers text-center">
            <div class="col-md-12 text-center ">
                <p class="p_font_style">
                    Well done for getting this far, Inspector. Now for the last piece of the puzzle.There are two pairs
                    of evidence that, when viewed Together, link Samuel Lima to the crime.
                </p>
                <h4 class="h2_font_style">Can you select them both?</h4>

            </div>
        </div>
        <div class="row">
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-10.png" class="firstevidence small-image small-image1 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-10.png" id="hover-image"
                        class="hover-image hover-image1 img-fluid" alt="">


                    <img src="/img/evidence/EVIDENCE FOLDER-10.png" class="lastevidence lastevidence1 img-fluid"
                        id="lastevidence" alt="">
                </div>
            </div>
            
            <!-- Add the remaining columns with adjusted column classes -->
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-11.png" class="firstevidence small-image small-image2 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-11.png" id="hover-image"
                            class="hover-image hover-image2 img-fluid" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-11.png" class="img-fluid lastevidence lastevidence2"
                            id="lastevidence" alt="">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-4.png" class="firstevidence small-image small-image3 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-4.png" id="hover-image" class="hover-image img-fluid hover-image3"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-4.png" class="lastevidence img-fluid lastevidence3" id=""
                            alt="">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-7.png" class="firstevidence small-image small-image4 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-7.png" id="hover-image" class="hover-image img-fluid hover-image4"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-7.png" id="lastevidence"
                            class="lastevidence img-fluid lastevidence4" alt="" data-value="4">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER.png" id="firstevidence"
                        class="firstevidence small-image small-image5 img-fluid" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER.png" id="hover-image" class="hover-image img-fluid hover-image5"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER.png" id="lastevidence"
                            class="lastevidence lastevidence5 img-fluid" alt="">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-2.png" class="firstevidence small-image small-image6 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-2.png" id="hover-image"
                        class="hover-image hover-image6 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-2.png" id="lastevidence"
                        class="lastevidence lastevidence6 img-fluid" alt="">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-5.png" class="firstevidence small-image small-image7 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-5.png" id="hover-image"
                        class="hover-image hover-image7 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-5.png" id="lastevidence lastevidence5"
                        class="lastevidence lastevidence7 img-fluid" alt="">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-8.png" class="firstevidence small-image small-image8 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-8.png" id="hover-image"
                        class="hover-image hover-image8 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-8.png" id="lastevidence"
                        class="lastevidence lastevidence8 img-fluid" alt="" data-value="8">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-1.png" class="firstevidence small-image small-image9 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-1.png" id="hover-image"
                        class="hover-image hover-image9 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-1.png" id="lastevidence"
                        class="lastevidence lastevidence9 img-fluid" alt="">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-3.png" class="firstevidence small-image small-image10 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-3.png" id="hover-image"
                        class="hover-image hover-image10 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-3.png" id="lastevidence"
                        class="lastevidence lastevidence10 img-fluid" alt="">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container">
                    <img src="/img/EVIDENCE FOLDER-6.png" class="firstevidence small-image small-image11 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-6.png" id="hover-image"
                        class="hover-image hover-image11 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-6.png" id="lastevidence"
                        class="lastevidence lastevidence11 img-fluid" alt="" data-value="11">
                </div>
            </div>
            
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="image-container" id="handInHandMatchBox">
                    <img src="/img/EVIDENCE FOLDER-9.png" class="firstevidence small-image small-image12 img-fluid"
                        alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-9.png" id="hover-image"
                        class="hover-image hover-image12 img-fluid" alt="">
                    <img src="/img/evidence/EVIDENCE FOLDER-9.png" id="lastevidence"
                        class="lastevidence lastevidence12 img-fluid" alt="" data-value="12">
                </div>
            </div>
        </div>

        <div class="col-md-12 text-center">
            <button class="btn" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center" id="buttons_countine"
                    alt="">
            </button>
        </div>




                <!-- 4th Modal -->
             <div class="modal fade" id="newspaper1" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                data-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <img src="<?php echo e(asset('img/newpaper1.jpeg')); ?>" class="img-fluid  btn1 text-center"alt="">
                </div>
            </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModalCente" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
            data-keyboard="false">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body">

                        <div class="p-5">
                        <h4 class="h2_font_style text-center mb-5">Excellent Work, Inspector.</h4>

                        <p class="p_font_style text-center mb-5">
                            We know from the Columbus Dispatch that Battaglia and Ventola were both suspected hitmen for
                            the Black Hand mafia. The threatening letter gave John Amicon until the end of May to
                            comply. Once that deadline passed, Sam Lima chose to contact both hitmen. Coincidence? Not
                            likely.
                            This is brilliant work. Looks like we've got all we need to press forward with the case.
                        </p>


                        <h4 class="h2_font_style text-center mb-5">YOU MAY NOW OPEN ENVELOPE A5</h4>
                        <button class="btn mb-3" onclick="closeModal()">
                            <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom" id="buttons_image"
                                alt="">
                        </button>
                    </div>
                </div>
                    <style>


                        .modal-content {
                        background-image: url('/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg'); /* Set the background image */
                        background-repeat: no-repeat;
                        background-size: cover;
                        /*  background-position: center;
                       background-size: auto;
                        height: 100%; */
                        }


                        .modal-body {
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: center;
                            text-align: center;
                            height: 100%;
                            color: white
                        }
                    </style>
                </div>
            </div>
        </div>



                

                <div class="modal fade" id="matchbox2" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
                data-keyboard="false">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
           <img src="<?php echo e(asset('img/matchbox2.jpeg')); ?>" class="img-fluid  btn1 text-center" alt="">
                </div>
            </div>


                


        


        <!-- Modal -->
        <div class="modal fade" id="matchbox1" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
            data-keyboard="false">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
         <img src="<?php echo e(asset('img/matchbox1.jpeg')); ?>" class="img-fluid  btn1 text-center"alt="">

        </div>
    </div>

        

        <div class="modal fade" id="newspaper2" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static"
        data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
     <img src="<?php echo e(asset('img/newpaper2.jpeg')); ?>" class="img-fluid  btn1 text-center"alt="">

    </div>
</div>













</body>

</html>



<script>
    $(document).ready(function() {
        $("#card_main_2").hide();
        $(".lastevidence").hide();
        $(".SOTBH_OverlayCard").hide();
        $("#evidence4").hide();
        $("#evidence3").hide();
        $("#case_1").click(function() {
            $("#card_main_1").hide();
            $("#card_main_2").show();
        });
        $("#buttons_countine").click(function() {
            $(".SOTBH_OverlayCard").show();
        });


    });
    const imageContainer = document.querySelector('.image-container');
    const smallImage = imageContainer.querySelector('.small-image');
    const hoverImage = imageContainer.querySelector('.hover-image');
    const lastEvidence = document.getElementById('evidence_10');
    const image = document.getElementById('SOTBH_OverlayCard');
    // Modify the image properties or perform actions
    smallImage.addEventListener('click', () => {

        smallImage.style.display = 'none';
        hoverImage.style.opacity = 1;
    });

    function openModal() {
        const modalContainer = document.getElementById('modalContainer');
        modalContainer.style.display = 'block';
    }

    // Function to close the modal
    function closeModal() {
        const modalContainer = document.getElementById('modalContainer');
        modalContainer.style.display = 'none';
    }
    $(".hover-image1").click(function() {
        $(".lastevidence1").show();
        $(".small-image1").hide();
        $(".hover-image1").hide();
    });
    $(".lastevidence1").click(function() {
        $(".small-image1").toggle();
        $(".hover-image1").toggle();
        $(".lastevidence1").toggle();
    });
    $(".hover-image2").click(function() {
        $(".lastevidence2").show();
        $(".small-image2").hide();
        $(".hover-image2").hide();
    });
    $(".lastevidence2").click(function() {
        $(".small-image2").toggle();
        $(".hover-image2").toggle();
        $(".lastevidence2").toggle();
    });
    $(".hover-image3").click(function() {
        $(".lastevidence3").show();
        $(".small-image3").hide();
        $(".hover-image3").hide();
    });
    $(".lastevidence3").click(function() {
        $(".small-image3").toggle();
        $(".hover-image3").toggle();
        $(".lastevidence3").toggle();
    });
    $(".hover-image4").click(function() {
        $(".lastevidence4").show();
        $(".small-image4").hide();
        $(".hover-image4").hide();
    });
    $(".lastevidence4").click(function() {
        $(".small-image4").toggle();
        $(".hover-image4").toggle();
        $(".lastevidence4").toggle();
    });
    $(".hover-image5").click(function() {
        $(".lastevidence5").show();
        $(".small-image5").hide();
        $(".hover-image5").hide();
    });
    $(".lastevidence5").click(function() {
        $(".small-image5").toggle();
        $(".hover-image5").toggle();
        $(".lastevidence5").toggle();
    });
    $(".hover-image6").click(function() {
        $(".lastevidence6").show();
        $(".small-image6").hide();
        $(".hover-image6").hide();
    });
    $(".lastevidence6").click(function() {
        $(".small-image6").toggle();
        $(".hover-image6").toggle();
        $(".lastevidence6").toggle();
    });
    $(".hover-image7").click(function() {
        $(".lastevidence7").show();
        $(".small-image7").hide();
        $(".hover-image7").hide();
    });
    $(".lastevidence7").click(function() {
        $(".small-image7").toggle();
        $(".hover-image7").toggle();
        $(".lastevidence7").toggle();
    });

    $(".lastevidence8").click(function() {
        $(".small-image8").toggle();
        $(".hover-image8").toggle();
        $(".lastevidence8").toggle();
    });
    $(".hover-image9").click(function() {
        $(".lastevidence9").show();
        $(".small-image9").hide();
        $(".hover-image9").hide();
    });
    $(".lastevidence9").click(function() {
        $(".small-image9").toggle();
        $(".hover-image9").toggle();
        $(".lastevidence9").toggle();
    });
    $(".hover-image10").click(function() {
        $(".lastevidence10").show();
        $(".small-image10").hide();
        $(".hover-image10").hide();
    });
    $(".lastevidence10").click(function() {
        $(".small-image10").toggle();
        $(".hover-image10").toggle();
        $(".lastevidence10").toggle();
    });
    $(".hover-image11").click(function() {
        $(".lastevidence11").show();
        $(".small-image11").hide();
        $(".hover-image11").hide();
    });
    $(".lastevidence11").click(function() {
        $(".small-image11").toggle();
        $(".hover-image11").toggle();
        $(".lastevidence11").toggle();
    });
    $(".hover-image12").click(function() {
        $(".lastevidence12").show();
        $(".small-image12").hide();
        $(".hover-image12").hide();
    });
    $(".lastevidence12").click(function() {
        $(".small-image12").toggle();
        $(".hover-image12").toggle();
        $(".lastevidence12").toggle();
    });

    $(".hover-image8").click(function() {
        $(".lastevidence8").show();
        $(".small-image8").hide();
        $(".hover-image8").hide();
    });

    // Using jquery
    // $("#handInHandMatchBox").click(function() {

    // var value    = $(".lastevidence12").data('value');


    //         alert(value);
    // });


    $(document).ready(function() {
  $('#buttons_countine').click(function() {


    var handInHandMatchBox = $(".lastevidence12:visible").data('value');
    var fuuitMarkt = $(".lastevidence8:visible").data('value');


    var outgoingReport = $(".lastevidence11:visible").data('value');
    var dispacthPageTwo = $(".lastevidence4:visible").data('value');



        if(outgoingReport === 11 && dispacthPageTwo === 4 && handInHandMatchBox === 12)
        {
          $('#exampleModalCente').modal('show');
        }
        else if (outgoingReport === 11 && dispacthPageTwo === 4 && fuuitMarkt === 8)
        {
            $('#exampleModalCente').modal('show');
        }
        else if (handInHandMatchBox === 12 && dispacthPageTwo === 4 && fuuitMarkt === 8)
        {
            $('#exampleModalCente').modal('show');
        }

         else if(outgoingReport === 11 && dispacthPageTwo === 4)
        {
         $('#matchbox1').modal('show');
        }
        else if (handInHandMatchBox === 12 && fuuitMarkt === 8)
        {
        $('#newspaper1').modal('show');
        }
        else if(fuuitMarkt === 8 || handInHandMatchBox === 12)
        {
            $('#newspaper2').modal('show');
        }
        else if(outgoingReport === 11 || dispacthPageTwo === 4)
        {
            $('#matchbox2').modal('show');
        }
        else
        {
        $('#exampleModalCente').modal('show');
        }
    });
    });









    // Toggle the selected class on image click
    // $('#image1, #image2').click(function() {
    //   $(this).toggleClass('selected');
    // });
//   });

</script>
<?php /**PATH C:\xampp\htdocs\live card\resources\views/cards/view1.blade.php ENDPATH**/ ?>