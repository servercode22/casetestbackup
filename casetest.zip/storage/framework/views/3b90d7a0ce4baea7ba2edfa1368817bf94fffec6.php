<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Card</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(asset('css/casetwo.css')); ?>">

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
</head>

<body class="full-screen-background">
    <div>
        <div class="container" id="card_main_1">
            <div class="row align-items-center" style="height: 100vh;">
                <div class="col-md-12 d-flex justify-content-center">
                    <div class="background-image-container">

                        <img src="/img/BOGART.png" class="img-fluid align-self-center" id="case_2">

                    </div>
                </div>
            </div>
        </div>

        <div class="container" id="mainCardhide">
            <div class="col-md-12 text-center">
                <b class="h3_font_style">Find evidence that confirm all three painting are fakes - and not
                    originals.</b>
                <p class="p_font_style">When you think you've got the right idea, pick a painting and submit your
                    evidence.</p>
            </div>
            <div class="col-md-12" id="">
                <div class="row justify-content-center">
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="image-container">
                            <img src="<?php echo e(asset('img/cas_two_imge/DREW_LEE.png')); ?>" alt="" class=" img-fluid"
                                id="drweleeImageHover">

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="image-container">
                            <img src="<?php echo e(asset('img/cas_two_imge/PHYLIS_ROWNING.png')); ?>" alt=""
                                class=" img-fluid" id="phylisImagehower">

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="image-container">
                            <img src="<?php echo e(asset('img/cas_two_imge/RICHARD_BAKER.png')); ?>" alt=""
                                class=" img-fluid" id="BAKER">

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 text-center">
                <button class="btn" class="btn btn-primary">
                    <img src="<?php echo e(asset('img/cas_two_imge/AUTO BUTTON.png')); ?>" class="img-fluid  btn1 text-center"
                        id="buttons_countine" alt="">
                </button>
            </div>
            <div class="row justify-content-md-center mt-2">

            </div>

        </div>
        

        

        <div class="container my_container_show justify-content-center" id="card_main_2" style="display: none">
            <div class="col-md-12 text-center">
                <p class="p_font_style">Find evidence that confirm all three painting are fakes - and not originals.</p>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">

                    <img src="<?php echo e(asset('img/cas_two_imge/DREW_LEE_T.png')); ?>" alt="" class="w-100">
                </div>
            </div>

            
            <div class="col-lg-12 col-md-12 col-sm-12 aftermodalclose_lee">
                <div class="image-container">
                    <p style="color:black;" class="p_font_style">Q1: &nbsp;Which Part of Mr Lee's painting is the most
                        suspicious?</p>
                </div>
            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 beforemodalview_lee">
                <div class="image-container">
                    <p style="color:black;" class="p_font_style">Q2: &nbsp;What's suspicious about it?</p>
                </div>
            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 beforemodalinputview_lee">
                <div class="image-container">
                    <p style="color:black;" class="p_font_style">Q2: &nbsp;What's suspicious about it?</p>
                </div>
            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 lastquesinputview_lee">
                <div class="image-container">
                    <p style="color:black;" class="p_font_style">Q3: &nbsp;Name the painting where you've seen this
                        before</p>
                </div>
            </div>
            
            <div class="row justify-content-center aftermodalclose_lee">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="signature">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON.png')); ?>" alt=""
                            class=" img-fluid" data-toggle="modal" data-target="#exampleModalCenter">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-2.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-4.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-1.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-3.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-5.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>

            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 beforemodalview_lee">
                <div class="image-container">
                    <div class="col-md-4">
                        <select class="form-control centered-placeholder" name="lee_option_1">
                            <option disabled selected value="">Select your answer</option>
                            <option value="option1">The signature is</option>
                            <option value="option2">The style is</option>
                            <option value="option3">The artist was</option>
                            <option value="option4">The thickness is</option>
                            <option value="option5">The printing company was</option>
                            <option value="option6">The pen was</option>
                            <option value="option7">The link is</option>
                            <option value="option8">The placement is</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select class="form-control centered-placeholder" name="lee_option_2">
                            <option disabled selected value="">Select your answer</option>
                            <option value="option1">wrong</option>
                            <option value="option2">in poor condition</option>
                            <option value="option3">in the incorrect place</option>
                            <option value="option4">in the wrong style</option>
                            <option value="option5">the same in other places</option>
                            <option value="option6">too heavy</option>
                            <option value="option7">the wrong color</option>
                            <option value="option8">too light</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-12 col-md-12 col-sm-12 lastquesinputview_lee">
                <div class="image-container">
                    <div class="col-md-4 justify-content-center">
                        <input type="text" class="form-control centered-placeholder" name=""
                            id="" placeholder="Type your answer here">
                    </div>
                </div>
            </div>
            <div class="col-md-12 text-center lastquesinputview_lee">
                <button class="btn" class="btn btn-primary">
                    <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                        id="submit__last_datalast_lee_evidence" alt="">
                </button>
            </div>
            


            <div class="col-md-12 text-center beforemodalview_lee">
                <button class="btn" class="btn btn-primary">
                    <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid  btn1 text-center"
                        id="submit_lee_evidence" alt="">
                </button>
            </div>



        </div>
        
        <div class="container my_containersecondimage_show justify-content-center" id="card_main_2"
            style="display: none">
            <div class="col-md-12 text-center">
                <p class="p_font_style">Find evidence that confirm all three painting are fakes - and not originals.
                </p>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">

                    <img src="<?php echo e(asset('img/PERSON SELECTION/TITLE/PHYLIS BROWNING TITLE.png')); ?>" alt=""
                        class="w-100">
                </div>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">
                    <p style="color:black;" class="p_font_style">Q1: &nbsp;Which Part of Mr's Phylis painting is the
                        most
                        suspicious?</p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="signature_missphyish">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON.png')); ?>" alt=""
                            class=" img-fluid" data-toggle="modal" data-target="#exampleModalCenter">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-2.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-4.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-1.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-3.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-5.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>

            </div>
            <div class="col-md-12 text-center">
                <button class="btn" class="btn btn-primary">
                    <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn1 text-center" id="buttons_countine"
                        alt="">
                </button>
            </div>




        </div>
        
        <div class="container my_containerthirdimage_show justify-content-center" id="card_main_2"
            style="display: none">
            <div class="col-md-12 text-center">
                <p class="p_font_style">Find evidence that confirm all three painting are fakes - and not originals.
                </p>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">

                    <img src="<?php echo e(asset('img/PERSON SELECTION/TITLE/RICHARD BAKER TITLE.png')); ?>" alt=""
                        class="w-100">
                </div>
            </div>


            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="image-container">
                    <p style="color:black;" class="p_font_style">Q1: &nbsp;Which Part of Mr Richard 's painting is the
                        most
                        suspicious?</p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container" id="signature_missphyish">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON.png')); ?>" alt=""
                            class=" img-fluid" data-toggle="modal" data-target="#exampleModalCenter">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-2.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-4.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-1.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-3.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="image-container">
                        <img src="<?php echo e(asset('img/cas_two_imge/SUSPCIOUS BUTTON-5.png')); ?>" alt=""
                            class=" img-fluid">

                    </div>
                </div>

            </div>
            <div class="col-md-12 text-center">
                <button class="btn" class="btn btn-primary">
                    <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn1 text-center" id="buttons_countine"
                        alt="">
                </button>
            </div>




        </div>
    </div>

    <!-- mr lee Modal -->
    <div class="modal fade" id="signaturemodal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
            <div class="modal-content justify-content-center">
                <div class="modal-body mt-5">
                    <div class="p-5 mt-5 mb-5 test">
                    <h4 class="h2_font_style mt-5">Correct !</h4>

                    <p class="p_font_style ">
                        There's something suspiciousabout the signatureon Mr Lee's painting. What could to be....
                    </p>

                    <button class="btn mt-5 mb-5">
                        <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues"
                            id="buttons_image" alt="">
                    </button>
                    </div>
                </div>
                <style>
                    .modal-content {
                        background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                        background-repeat: no-repeat;
                        /* background-size: cover; */
                        /* background-size: cover; */
                        background-position: center;
                    }

                    .modal-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        height: 100%;
                        color: white
                    }
                </style>
            </div>
        </div>
    </div>
    <!-- mr lee after input Modal -->
    <div class="modal fade" id="inputmodallee" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
            <div class="modal-content justify-content-center">
                <div class="modal-body mt-5">
                    <div class="p-5 mt-5 mb-5 test">
                    <h4 class="h2_font_style">Correct !</h4>

                    <p class="p_font_style ">
                        That's it! we've definitely seen the signature somewhere else before. But where?
                    </p>

                    <button class="btn mt-5 mb-5">
                        <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom countinues"
                            id="addtolast_lee" alt="">
                    </button>
                    </div>
                </div>
                <style>
                    .modal-content {
                        background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                        background-repeat: no-repeat;
                        /* background-size: cover; */
                        /* background-position: center; */
                    }

                    .modal-body {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        height: 100%;
                        color: white
                    }
                </style>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="inputmodal_last_lee" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
        <div class="modal-content justify-content-center">
            <div class="modal-body ">
                <div class="p-5 mt-5 mb-5 test">
                <h4 class="h2_font_style">Bingo !</h4>

                <p class="p_font_style ">
                    Nova Oz never signed his namethe same way twice,
                    but the same signature appears on both 'Reflection'
                    and 'Home at Last'
                </p>
                <p class="p_font_style ">
                    We known that 'Reflection' is a genuine painting,
                    because Nova Oz himself presented it to the gallery
                    which name Mr Lee's painting must be a fake.
                </p>


                <button class="btn" >
                    <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid  btn2 zoom lastpageid countinues"
                        id="addtolast_lee" alt="">
                </button>
            </div>
            </div>
            <style>
                .modal-content {
                    background-image: url('/img/modalsignture/BOGART_OverlayCard-02 1.jpg');
                    background-repeat: no-repeat;
                    /* background-size: cover; */
                    /* background-position: center; */
                }

                .modal-body {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    text-align: center;
                    height: 100%;
                    color: white
                }
            </style>
        </div>
    </div>

</div>
    <script>
        $(document).ready(function() {
            $('#mainCardhide').hide();
            $(".my_container_show").hide();
            $(".my_containersecondimage_show").hide();
            $(".my_containerthirdimage_show").hide();
            $(".beforemodalinputview_lee").hide();
            $(".lastquesinputview_lee").hide();
            $("#case_2").click(function() {
                $('#mainCardhide').show();
                $("#case_2").hide();
                $("#card_main_1").hide()
            });
            $("#buttons_countine").click(function() {
                $(".SOTBH_OverlayCard").show();
            });


        });
        $('#drweleeImageHover').click(function() {
            $('#mainCardhide').hide();
            $(".my_container_show").show();
            $(".beforemodalview_lee").hide();
        });
        $("#phylisImagehower").click(function() {
            $('#mainCardhide').hide();
            $(".my_containersecondimage_show").show();
        });
        $("#BAKER").click(function() {
            $('#mainCardhide').hide();
            $(".my_containerthirdimage_show").show();
        });
        $(".countinues").click(function() {

            $('#signaturemodal').modal('hide');
            $(".aftermodalclose_lee").hide();
            $(".beforemodalview_lee").show();
            $(".aftermodalclose").hide();

        });
        $(document).ready(function() {
            $('#signature').click(function() {

                $('#signaturemodal').modal('show');

            });
            $("#submit_lee_evidence").click(function() {
                $('#inputmodallee').modal('show');
            });
            $("#addtolast_lee").click(function() {
                $('#inputmodallee').modal('hide');
                $(".aftermodalclose_lee").hide();
                $(".beforemodalview_lee").hide();
                $(".aftermodalclose").hide();
                $(".lastquesinputview_lee").show();
            });
            $("#submit__last_datalast_lee_evidence").click(function() {
                $('#inputmodal_last_lee').modal('show');
            });
            $(".lastpageid").click(function() {
                $("#inputmodal_last_lee").modal('hide');
                location.reload();
            });
});

        // });
    </script>
</body>

</html>

















<?php /**PATH /home/thelogix/casetest.crossdevlogix.com/resources/views/cards/casetwo/view.blade.php ENDPATH**/ ?>