<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Card</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="css/card1.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
</head>

<body>
    <div class="container-fluid" id="card_main_1">
        <div class="text-center">
            <button class="btn">
                <img src="/img/BLACK HAND.png" class="img-fluid zoom" id="case_1" alt="">
            </button>
        </div>
    </div>
    <div class="container" id="card_main_2">
        <div class="container">
            <div class="col-md-12 text-center">
                <p>Well done for getting this far, Inspector.Now for the last piece of the puzzle.</p>
                <p>There are two pairs of evidence that,when viewed Together, link Samuel Lima to the crime</p>
                <h4>Can you Select them both</h4>

            </div>
            <div class="row">
                <div class="col-md-3 ">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-10.png" id=""
                            class="firstevidence small-image small-image1" alt="" style="">
                        <img src="/img/selecter/EVIDENCE FOLDER-10.png" id="hover-image"
                            class="hover-image hover-image1" alt="">


                        <img src="/img/evidence/EVIDENCE FOLDER-10.png" class="lastevidence lastevidence1"
                            id="lastevidence" alt="">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-11.png" class=" firstevidence small-image small-image2"
                            id="small-image firstevidence" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-11.png" id="hover-image"
                            class="hover-image hover-image2" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-11.png" class="lastevidence lastevidence2"
                            id="lastevidence" alt="">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-4.png" class="firstevidence small-image small-image3"
                            id="firstevidence small-image" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-4.png" id="hover-image" class="hover-image hover-image3"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-4.png" class="lastevidence lastevidence3" id=""
                            alt="">

                    </div>
                </div>
                <div class="col-md-3 ">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-7.png" class="firstevidence small-image small-image4"
                            id="firstevidence" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-7.png" id="hover-image" class="hover-image hover-image4"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-7.png" id="lastevidence"
                            class="lastevidence lastevidence4" alt="">
                    </div>
                </div>
            </div>


            <div class="row mt-4">
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER.png" id="firstevidence"
                            class="firstevidence small-image small-image5" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER.png" id="hover-image" class="hover-image hover-image5"
                            alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER.png" id="lastevidence"
                            class="lastevidence lastevidence5" alt="">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/eVIDENCE FOLDER-2.png" class="firstevidence small-image small-image6"
                            alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-2.png" id="hover-image"
                            class="hover-image hover-image6" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-2.png" id="lastevidence"
                            class="lastevidence lastevidence6" alt="">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-5.png" class="firstevidence small-image small-image7"
                            alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-5.png" id="hover-image"
                            class="hover-image hover-image7" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-5.png" id="lastevidence lastevidence5"
                            class="lastevidence lastevidence7" alt="">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-8.png" class="firstevidence small-image small-image8"
                            alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-8.png" id="hover-image"
                            class="hover-image hover-image8" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-8.png" id="lastevidence"
                            class="lastevidence lastevidence8" alt="">
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-1.png" class="firstevidence small-image small-image9"
                            id="firstevidence" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-1.png" id="hover-image"
                            class="hover-image hover-image9" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-1.png" id="lastevidence"
                            class="lastevidence lastevidence9" alt="">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-3.png" class="small-image  small-image10 firstevidence"
                            id="firstevidence" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-3.png" id="hover-image"
                            class="hover-image hover-image10" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-3.png" id="lastevidence"
                            class="lastevidence lastevidence10" alt="">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-6.png" class="small-image small-image11 firstevidence"
                            id="firstevidence" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-6.png" id="hover-image"
                            class="hover-image hover-image11" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-6.png" id="lastevidence"
                            class="lastevidence lastevidence11" alt="">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="image-container">
                        <img src="/img/EVIDENCE FOLDER-9.png" class="small-image small-image12 firstevidence"
                            id="firstevidence" alt="">
                        <img src="/img/selecter/EVIDENCE FOLDER-9.png" id="hover-image"
                            class="hover-image hover-image12" alt="">
                        <img src="/img/evidence/EVIDENCE FOLDER-9.png" id="lastevidence"
                            class="lastevidence lastevidence12" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-4 mb-4 text-center">
                <div id="modalContainer" class="modal-container">
                  <img src="/img/SOTB OVERLAYS/SOTBH_OverlayCard 1.jpg" id="SOTBH_OverlayCard" class="SOTBH_OverlayCard" alt="">
                  <div class="image-text">
                    <h4>Excellent Work, Inspector.</h4>
                    <p>
                      We know the Columbus Dispatch that Battaglia and Ventola were both suspected hitmen for the Black Hand mafia. The threatening letter gave John Amicon until the end of May to comply. Once that deadline passed, Sam Lima chose to contact both hitmen. Coincidence? Not likely.
                      This is brilliant work. Looks like we've got all we need to press forward with the case.
                    </p>
                    <h3 class="image-texts">YOU MAY NOW OPEN ENVELOPE A5</h3>
                    <button class="btn" onclick="closeModal()">
                      <img src="/img/buttons/AUTO BUTTON.png" class="img-fluid zoom" id="buttons_image" alt="">
                    </button>
                  </div>
                </div>
              
                <!-- Button to open the modal -->
                <button class="btn" onclick="openModal()">
                  <img src="/img/buttons/AUTO BUTTON-2.png" class="img-fluid zoom" id="buttons_countine" alt="">
                </button>
              </div>
        </div>
    </div>






</body>

</html>



<script>
    $(document).ready(function() {
        $("#card_main_2").hide();
        $(".lastevidence").hide();
        $(".SOTBH_OverlayCard").hide();
        $("#evidence4").hide();
        $("#evidence3").hide();
        $("#case_1").click(function() {
            $("#card_main_1").hide();
            $("#card_main_2").show();
        });
        $("#buttons_countine").click(function() {
            $(".SOTBH_OverlayCard").show();
        });


    });
    const imageContainer = document.querySelector('.image-container');
    const smallImage = imageContainer.querySelector('.small-image');
    const hoverImage = imageContainer.querySelector('.hover-image');
    const lastEvidence = document.getElementById('evidence_10');
    const image = document.getElementById('SOTBH_OverlayCard');
    // Modify the image properties or perform actions
    image.style.zIndex = '9999';
    image.style.display = 'block';
    smallImage.addEventListener('click', () => {

        smallImage.style.display = 'none';
        hoverImage.style.opacity = 1;
    });

    function openModal() {
        const modalContainer = document.getElementById('modalContainer');
        modalContainer.style.display = 'block';
    }

    // Function to close the modal
    function closeModal() {
        const modalContainer = document.getElementById('modalContainer');
        modalContainer.style.display = 'none';
    }
    $(".hover-image1").click(function() {
        $(".lastevidence1").show();
        $(".small-image1").hide();
        $(".hover-image1").hide();
    });
    $(".lastevidence1").click(function() {
        $(".small-image1").toggle();
        $(".hover-image1").toggle();
        $(".lastevidence1").toggle();
    });
    $(".hover-image2").click(function() {
        $(".lastevidence2").show();
        $(".small-image2").hide();
        $(".hover-image2").hide();
    });
    $(".lastevidence2").click(function() {
        $(".small-image2").toggle();
        $(".hover-image2").toggle();
        $(".lastevidence2").toggle();
    });
    $(".hover-image3").click(function() {
        $(".lastevidence3").show();
        $(".small-image3").hide();
        $(".hover-image3").hide();
    });
    $(".lastevidence3").click(function() {
        $(".small-image3").toggle();
        $(".hover-image3").toggle();
        $(".lastevidence3").toggle();
    });
    $(".hover-image4").click(function() {
        $(".lastevidence4").show();
        $(".small-image4").hide();
        $(".hover-image4").hide();
    });
    $(".lastevidence4").click(function() {
        $(".small-image4").toggle();
        $(".hover-image4").toggle();
        $(".lastevidence4").toggle();
    });
    $(".hover-image5").click(function() {
        $(".lastevidence5").show();
        $(".small-image5").hide();
        $(".hover-image5").hide();
    });
    $(".lastevidence5").click(function() {
        $(".small-image5").toggle();
        $(".hover-image5").toggle();
        $(".lastevidence5").toggle();
    });
    $(".hover-image6").click(function() {
        $(".lastevidence6").show();
        $(".small-image6").hide();
        $(".hover-image6").hide();
    });
    $(".lastevidence6").click(function() {
        $(".small-image6").toggle();
        $(".hover-image6").toggle();
        $(".lastevidence6").toggle();
    });
    $(".hover-image7").click(function() {
        $(".lastevidence7").show();
        $(".small-image7").hide();
        $(".hover-image7").hide();
    });
    $(".lastevidence7").click(function() {
        $(".small-image7").toggle();
        $(".hover-image7").toggle();
        $(".lastevidence7").toggle();
    });
    $(".hover-image8").click(function() {
        $(".lastevidence8").show();
        $(".small-image8").hide();
        $(".hover-image8").hide();
    });
    $(".lastevidence8").click(function() {
        $(".small-image8").toggle();
        $(".hover-image8").toggle();
        $(".lastevidence8").toggle();
    });
    $(".hover-image9").click(function() {
        $(".lastevidence9").show();
        $(".small-image9").hide();
        $(".hover-image9").hide();
    });
    $(".lastevidence9").click(function() {
        $(".small-image9").toggle();
        $(".hover-image9").toggle();
        $(".lastevidence9").toggle();
    });
    $(".hover-image10").click(function() {
        $(".lastevidence10").show();
        $(".small-image10").hide();
        $(".hover-image10").hide();
    });
    $(".lastevidence10").click(function() {
        $(".small-image10").toggle();
        $(".hover-image10").toggle();
        $(".lastevidence10").toggle();
    });
    $(".hover-image11").click(function() {
        $(".lastevidence11").show();
        $(".small-image11").hide();
        $(".hover-image11").hide();
    });
    $(".lastevidence11").click(function() {
        $(".small-image11").toggle();
        $(".hover-image11").toggle();
        $(".lastevidence11").toggle();
    });
    $(".hover-image12").click(function() {
        $(".lastevidence12").show();
        $(".small-image12").hide();
        $(".hover-image12").hide();
    });
    $(".lastevidence12").click(function() {
        $(".small-image12").toggle();
        $(".hover-image12").toggle();
        $(".lastevidence12").toggle();
    });
</script>
<?php /**PATH C:\xampp\htdocs\cardsprojectsmub\resources\views/cards/view1.blade.php ENDPATH**/ ?>